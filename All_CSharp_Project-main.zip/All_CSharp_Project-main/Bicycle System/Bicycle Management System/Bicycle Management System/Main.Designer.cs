﻿namespace Bicycle_Management_System
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.cUSTOMERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cUSTOMERINFOToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sUPPLIERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cUSTDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pURCHASEDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sUPPLIERToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pRODUCTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sALEPRODUCTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pURCHASEPRODUCTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aDDBICYCLEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rEPORTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.custReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saleReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.purchaseReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sECURITYToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changePasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cUSTOMERToolStripMenuItem,
            this.sUPPLIERToolStripMenuItem,
            this.pRODUCTToolStripMenuItem,
            this.rEPORTToolStripMenuItem,
            this.sECURITYToolStripMenuItem,
            this.eXITToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(728, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // cUSTOMERToolStripMenuItem
            // 
            this.cUSTOMERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cUSTOMERINFOToolStripMenuItem});
            this.cUSTOMERToolStripMenuItem.Name = "cUSTOMERToolStripMenuItem";
            this.cUSTOMERToolStripMenuItem.Size = new System.Drawing.Size(89, 21);
            this.cUSTOMERToolStripMenuItem.Text = "CUSTOMER";
            // 
            // cUSTOMERINFOToolStripMenuItem
            // 
            this.cUSTOMERINFOToolStripMenuItem.Name = "cUSTOMERINFOToolStripMenuItem";
            this.cUSTOMERINFOToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.cUSTOMERINFOToolStripMenuItem.Text = "CUSTOMER INFO";
            this.cUSTOMERINFOToolStripMenuItem.Click += new System.EventHandler(this.cUSTOMERINFOToolStripMenuItem_Click);
            // 
            // sUPPLIERToolStripMenuItem
            // 
            this.sUPPLIERToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cUSTDETAILSToolStripMenuItem,
            this.pURCHASEDETAILSToolStripMenuItem,
            this.sUPPLIERToolStripMenuItem1});
            this.sUPPLIERToolStripMenuItem.Name = "sUPPLIERToolStripMenuItem";
            this.sUPPLIERToolStripMenuItem.Size = new System.Drawing.Size(78, 21);
            this.sUPPLIERToolStripMenuItem.Text = "SUPPLIER";
            // 
            // cUSTDETAILSToolStripMenuItem
            // 
            this.cUSTDETAILSToolStripMenuItem.Name = "cUSTDETAILSToolStripMenuItem";
            this.cUSTDETAILSToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.cUSTDETAILSToolStripMenuItem.Text = "CUST_DETAILS";
            this.cUSTDETAILSToolStripMenuItem.Click += new System.EventHandler(this.cUSTDETAILSToolStripMenuItem_Click);
            // 
            // pURCHASEDETAILSToolStripMenuItem
            // 
            this.pURCHASEDETAILSToolStripMenuItem.Name = "pURCHASEDETAILSToolStripMenuItem";
            this.pURCHASEDETAILSToolStripMenuItem.Size = new System.Drawing.Size(198, 22);
            this.pURCHASEDETAILSToolStripMenuItem.Text = "PURCHASE_DETAILS";
            this.pURCHASEDETAILSToolStripMenuItem.Click += new System.EventHandler(this.pURCHASEDETAILSToolStripMenuItem_Click);
            // 
            // sUPPLIERToolStripMenuItem1
            // 
            this.sUPPLIERToolStripMenuItem1.Name = "sUPPLIERToolStripMenuItem1";
            this.sUPPLIERToolStripMenuItem1.Size = new System.Drawing.Size(198, 22);
            this.sUPPLIERToolStripMenuItem1.Text = "SUPPLIER";
            this.sUPPLIERToolStripMenuItem1.Click += new System.EventHandler(this.sUPPLIERToolStripMenuItem1_Click);
            // 
            // pRODUCTToolStripMenuItem
            // 
            this.pRODUCTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sALEPRODUCTToolStripMenuItem,
            this.pURCHASEPRODUCTToolStripMenuItem,
            this.aDDBICYCLEToolStripMenuItem});
            this.pRODUCTToolStripMenuItem.Name = "pRODUCTToolStripMenuItem";
            this.pRODUCTToolStripMenuItem.Size = new System.Drawing.Size(81, 21);
            this.pRODUCTToolStripMenuItem.Text = "PRODUCT";
            // 
            // sALEPRODUCTToolStripMenuItem
            // 
            this.sALEPRODUCTToolStripMenuItem.Name = "sALEPRODUCTToolStripMenuItem";
            this.sALEPRODUCTToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.sALEPRODUCTToolStripMenuItem.Text = "SALE PRODUCT";
            this.sALEPRODUCTToolStripMenuItem.Click += new System.EventHandler(this.sALEPRODUCTToolStripMenuItem_Click);
            // 
            // pURCHASEPRODUCTToolStripMenuItem
            // 
            this.pURCHASEPRODUCTToolStripMenuItem.Name = "pURCHASEPRODUCTToolStripMenuItem";
            this.pURCHASEPRODUCTToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.pURCHASEPRODUCTToolStripMenuItem.Text = "PURCHASE PRODUCT";
            this.pURCHASEPRODUCTToolStripMenuItem.Click += new System.EventHandler(this.pURCHASEPRODUCTToolStripMenuItem_Click);
            // 
            // aDDBICYCLEToolStripMenuItem
            // 
            this.aDDBICYCLEToolStripMenuItem.Name = "aDDBICYCLEToolStripMenuItem";
            this.aDDBICYCLEToolStripMenuItem.Size = new System.Drawing.Size(207, 22);
            this.aDDBICYCLEToolStripMenuItem.Text = "ADD BICYCLE";
            this.aDDBICYCLEToolStripMenuItem.Click += new System.EventHandler(this.aDDBICYCLEToolStripMenuItem_Click);
            // 
            // rEPORTToolStripMenuItem
            // 
            this.rEPORTToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.custReportToolStripMenuItem,
            this.saleReportToolStripMenuItem,
            this.purchaseReportToolStripMenuItem});
            this.rEPORTToolStripMenuItem.Name = "rEPORTToolStripMenuItem";
            this.rEPORTToolStripMenuItem.Size = new System.Drawing.Size(69, 21);
            this.rEPORTToolStripMenuItem.Text = "REPORT";
            this.rEPORTToolStripMenuItem.Click += new System.EventHandler(this.rEPORTToolStripMenuItem_Click_1);
            // 
            // custReportToolStripMenuItem
            // 
            this.custReportToolStripMenuItem.Name = "custReportToolStripMenuItem";
            this.custReportToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.custReportToolStripMenuItem.Text = "Cust_Report";
            this.custReportToolStripMenuItem.Click += new System.EventHandler(this.custReportToolStripMenuItem_Click);
            // 
            // saleReportToolStripMenuItem
            // 
            this.saleReportToolStripMenuItem.Name = "saleReportToolStripMenuItem";
            this.saleReportToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.saleReportToolStripMenuItem.Text = "Sale Report";
            this.saleReportToolStripMenuItem.Click += new System.EventHandler(this.saleReportToolStripMenuItem_Click);
            // 
            // purchaseReportToolStripMenuItem
            // 
            this.purchaseReportToolStripMenuItem.Name = "purchaseReportToolStripMenuItem";
            this.purchaseReportToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.purchaseReportToolStripMenuItem.Text = "Purchase Report";
            this.purchaseReportToolStripMenuItem.Click += new System.EventHandler(this.purchaseReportToolStripMenuItem_Click);
            // 
            // sECURITYToolStripMenuItem
            // 
            this.sECURITYToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.changePasswordToolStripMenuItem});
            this.sECURITYToolStripMenuItem.Name = "sECURITYToolStripMenuItem";
            this.sECURITYToolStripMenuItem.Size = new System.Drawing.Size(79, 21);
            this.sECURITYToolStripMenuItem.Text = "SECURITY";
            // 
            // changePasswordToolStripMenuItem
            // 
            this.changePasswordToolStripMenuItem.Name = "changePasswordToolStripMenuItem";
            this.changePasswordToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.changePasswordToolStripMenuItem.Text = "Change Password";
            this.changePasswordToolStripMenuItem.Click += new System.EventHandler(this.changePasswordToolStripMenuItem_Click);
            // 
            // eXITToolStripMenuItem
            // 
            this.eXITToolStripMenuItem.Name = "eXITToolStripMenuItem";
            this.eXITToolStripMenuItem.Size = new System.Drawing.Size(48, 21);
            this.eXITToolStripMenuItem.Text = "EXIT";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Bicycle_Management_System.Properties.Resources._3;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(728, 461);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem cUSTOMERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cUSTOMERINFOToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sUPPLIERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sALEPRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pURCHASEPRODUCTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cUSTDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pURCHASEDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sUPPLIERToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem rEPORTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sECURITYToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aDDBICYCLEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem custReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saleReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem purchaseReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changePasswordToolStripMenuItem;
    }
}