﻿namespace Hostal_managemnt
{
    partial class Mian
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Mian));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.masterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addmissionDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.transactionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feesDEtailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roomDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.daillyReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incomingDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outGoingDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.studentAddmissionReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feesinformationReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outgoingListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.incomingdetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.feesListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.adimissionListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outgoingreportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.roomReportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutUsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterToolStripMenuItem,
            this.transactionToolStripMenuItem,
            this.daillyReportToolStripMenuItem,
            this.reportToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1028, 26);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // masterToolStripMenuItem
            // 
            this.masterToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentToolStripMenuItem,
            this.addmissionDetailToolStripMenuItem});
            this.masterToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.masterToolStripMenuItem.Name = "masterToolStripMenuItem";
            this.masterToolStripMenuItem.Size = new System.Drawing.Size(83, 22);
            this.masterToolStripMenuItem.Text = "Master ";
            this.masterToolStripMenuItem.Click += new System.EventHandler(this.masterToolStripMenuItem_Click);
            // 
            // studentToolStripMenuItem
            // 
            this.studentToolStripMenuItem.Name = "studentToolStripMenuItem";
            this.studentToolStripMenuItem.Size = new System.Drawing.Size(260, 22);
            this.studentToolStripMenuItem.Text = "Student_Informationr";
            this.studentToolStripMenuItem.Click += new System.EventHandler(this.studentToolStripMenuItem_Click);
            // 
            // addmissionDetailToolStripMenuItem
            // 
            this.addmissionDetailToolStripMenuItem.Name = "addmissionDetailToolStripMenuItem";
            this.addmissionDetailToolStripMenuItem.Size = new System.Drawing.Size(260, 22);
            this.addmissionDetailToolStripMenuItem.Text = "Addmission_Detail";
            this.addmissionDetailToolStripMenuItem.Click += new System.EventHandler(this.addmissionDetailToolStripMenuItem_Click);
            // 
            // transactionToolStripMenuItem
            // 
            this.transactionToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.feesDEtailsToolStripMenuItem,
            this.roomDetailsToolStripMenuItem});
            this.transactionToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transactionToolStripMenuItem.Name = "transactionToolStripMenuItem";
            this.transactionToolStripMenuItem.Size = new System.Drawing.Size(121, 22);
            this.transactionToolStripMenuItem.Text = "Transaction";
            this.transactionToolStripMenuItem.Click += new System.EventHandler(this.transactionToolStripMenuItem_Click);
            // 
            // feesDEtailsToolStripMenuItem
            // 
            this.feesDEtailsToolStripMenuItem.Name = "feesDEtailsToolStripMenuItem";
            this.feesDEtailsToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.feesDEtailsToolStripMenuItem.Text = "Fees_Details";
            this.feesDEtailsToolStripMenuItem.Click += new System.EventHandler(this.feesDEtailsToolStripMenuItem_Click);
            // 
            // roomDetailsToolStripMenuItem
            // 
            this.roomDetailsToolStripMenuItem.Name = "roomDetailsToolStripMenuItem";
            this.roomDetailsToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.roomDetailsToolStripMenuItem.Text = "Room Details";
            this.roomDetailsToolStripMenuItem.Click += new System.EventHandler(this.roomDetailsToolStripMenuItem_Click);
            // 
            // daillyReportToolStripMenuItem
            // 
            this.daillyReportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.incomingDetailsToolStripMenuItem,
            this.outGoingDetailsToolStripMenuItem});
            this.daillyReportToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.daillyReportToolStripMenuItem.Name = "daillyReportToolStripMenuItem";
            this.daillyReportToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.daillyReportToolStripMenuItem.Text = "Dailly_Report";
            // 
            // incomingDetailsToolStripMenuItem
            // 
            this.incomingDetailsToolStripMenuItem.Name = "incomingDetailsToolStripMenuItem";
            this.incomingDetailsToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.incomingDetailsToolStripMenuItem.Text = "Incoming_Details";
            this.incomingDetailsToolStripMenuItem.Click += new System.EventHandler(this.incomingDetailsToolStripMenuItem_Click);
            // 
            // outGoingDetailsToolStripMenuItem
            // 
            this.outGoingDetailsToolStripMenuItem.Name = "outGoingDetailsToolStripMenuItem";
            this.outGoingDetailsToolStripMenuItem.Size = new System.Drawing.Size(225, 22);
            this.outGoingDetailsToolStripMenuItem.Text = "OutGoing_Details";
            this.outGoingDetailsToolStripMenuItem.Click += new System.EventHandler(this.outGoingDetailsToolStripMenuItem_Click);
            // 
            // reportToolStripMenuItem
            // 
            this.reportToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.studentAddmissionReportToolStripMenuItem,
            this.feesinformationReportToolStripMenuItem,
            this.outgoingListToolStripMenuItem,
            this.incomingdetailToolStripMenuItem,
            this.feesListToolStripMenuItem,
            this.adimissionListToolStripMenuItem,
            this.outgoingreportToolStripMenuItem,
            this.toolStripMenuItem2,
            this.roomReportToolStripMenuItem});
            this.reportToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportToolStripMenuItem.Name = "reportToolStripMenuItem";
            this.reportToolStripMenuItem.Size = new System.Drawing.Size(77, 22);
            this.reportToolStripMenuItem.Text = "Report";
            this.reportToolStripMenuItem.Click += new System.EventHandler(this.reportToolStripMenuItem_Click);
            // 
            // studentAddmissionReportToolStripMenuItem
            // 
            this.studentAddmissionReportToolStripMenuItem.Name = "studentAddmissionReportToolStripMenuItem";
            this.studentAddmissionReportToolStripMenuItem.Size = new System.Drawing.Size(314, 22);
            this.studentAddmissionReportToolStripMenuItem.Text = "Student_Addmission Report";
            this.studentAddmissionReportToolStripMenuItem.Click += new System.EventHandler(this.studentAddmissionReportToolStripMenuItem_Click);
            // 
            // feesinformationReportToolStripMenuItem
            // 
            this.feesinformationReportToolStripMenuItem.Name = "feesinformationReportToolStripMenuItem";
            this.feesinformationReportToolStripMenuItem.Size = new System.Drawing.Size(314, 22);
            this.feesinformationReportToolStripMenuItem.Text = "fees_information  Report";
            this.feesinformationReportToolStripMenuItem.Click += new System.EventHandler(this.feesinformationReportToolStripMenuItem_Click);
            // 
            // outgoingListToolStripMenuItem
            // 
            this.outgoingListToolStripMenuItem.Name = "outgoingListToolStripMenuItem";
            this.outgoingListToolStripMenuItem.Size = new System.Drawing.Size(314, 22);
            this.outgoingListToolStripMenuItem.Text = "Outgoing list";
            this.outgoingListToolStripMenuItem.Click += new System.EventHandler(this.outgoingListToolStripMenuItem_Click);
            // 
            // incomingdetailToolStripMenuItem
            // 
            this.incomingdetailToolStripMenuItem.Name = "incomingdetailToolStripMenuItem";
            this.incomingdetailToolStripMenuItem.Size = new System.Drawing.Size(314, 22);
            this.incomingdetailToolStripMenuItem.Text = " Incoming  list";
            this.incomingdetailToolStripMenuItem.Click += new System.EventHandler(this.incomingdetailToolStripMenuItem_Click);
            // 
            // feesListToolStripMenuItem
            // 
            this.feesListToolStripMenuItem.Name = "feesListToolStripMenuItem";
            this.feesListToolStripMenuItem.Size = new System.Drawing.Size(314, 22);
            this.feesListToolStripMenuItem.Text = "fees list";
            this.feesListToolStripMenuItem.Click += new System.EventHandler(this.feesListToolStripMenuItem_Click);
            // 
            // adimissionListToolStripMenuItem
            // 
            this.adimissionListToolStripMenuItem.Name = "adimissionListToolStripMenuItem";
            this.adimissionListToolStripMenuItem.Size = new System.Drawing.Size(314, 22);
            this.adimissionListToolStripMenuItem.Text = "Adimission list";
            this.adimissionListToolStripMenuItem.Click += new System.EventHandler(this.adimissionListToolStripMenuItem_Click);
            // 
            // outgoingreportToolStripMenuItem
            // 
            this.outgoingreportToolStripMenuItem.Name = "outgoingreportToolStripMenuItem";
            this.outgoingreportToolStripMenuItem.Size = new System.Drawing.Size(314, 22);
            this.outgoingreportToolStripMenuItem.Text = "outgoing_report";
            this.outgoingreportToolStripMenuItem.Click += new System.EventHandler(this.outgoingreportToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(314, 22);
            this.toolStripMenuItem2.Text = "Fees_Report";
            this.toolStripMenuItem2.Click += new System.EventHandler(this.toolStripMenuItem2_Click);
            // 
            // roomReportToolStripMenuItem
            // 
            this.roomReportToolStripMenuItem.Name = "roomReportToolStripMenuItem";
            this.roomReportToolStripMenuItem.Size = new System.Drawing.Size(314, 22);
            this.roomReportToolStripMenuItem.Text = "Room_Report";
            this.roomReportToolStripMenuItem.Click += new System.EventHandler(this.roomReportToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutUsToolStripMenuItem,
            this.toolStripMenuItem1});
            this.aboutToolStripMenuItem.Font = new System.Drawing.Font("Lucida Fax", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(102, 22);
            this.aboutToolStripMenuItem.Text = " About Us";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // aboutUsToolStripMenuItem
            // 
            this.aboutUsToolStripMenuItem.Name = "aboutUsToolStripMenuItem";
            this.aboutUsToolStripMenuItem.Size = new System.Drawing.Size(153, 22);
            this.aboutUsToolStripMenuItem.Text = "About Us";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            // 
            // Mian
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1028, 538);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Mian";
            this.Text = "Mian";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem masterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addmissionDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem transactionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feesDEtailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem daillyReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incomingDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outGoingDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem studentAddmissionReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feesinformationReportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutUsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outgoingListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem incomingdetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem feesListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem adimissionListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roomDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem outgoingreportToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem roomReportToolStripMenuItem;
    }
}