﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesAndInventoryDummy
{
    public partial class UserControlproducts : UserControl
    {
        private static UserControlproducts _instance;

        public static UserControlproducts Instance1
        {
            get
            {
                if (_instance == null)
                    _instance = new UserControlproducts();
                return _instance;
            }
        }
        public UserControlproducts()
        {
            InitializeComponent();
        }

        public static Control Instance { get; set; }

        private void UserControlproducts_Load(object sender, EventArgs e)
        {

        }
    }
}
