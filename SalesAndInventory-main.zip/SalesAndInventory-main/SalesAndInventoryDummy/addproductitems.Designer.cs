﻿namespace SalesAndInventoryDummy
{
    partial class addproductitems
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paneladditems = new System.Windows.Forms.Panel();
            this.paneladditem = new System.Windows.Forms.Panel();
            this.iconBtnquantity = new FontAwesome.Sharp.IconButton();
            this.iconBtnitem = new FontAwesome.Sharp.IconButton();
            this.iconBtndropdown = new FontAwesome.Sharp.IconButton();
            this.iconBtnadditems = new FontAwesome.Sharp.IconButton();
            this.iconPicsearch = new FontAwesome.Sharp.IconPictureBox();
            this.paneladjustitem = new System.Windows.Forms.Panel();
            this.labelstockvalueamount = new System.Windows.Forms.Label();
            this.labelstockqtyamount = new System.Windows.Forms.Label();
            this.labelstockvalue = new System.Windows.Forms.Label();
            this.labelstockquantity = new System.Windows.Forms.Label();
            this.labelexcl = new System.Windows.Forms.Label();
            this.labelpurpriceamount = new System.Windows.Forms.Label();
            this.labelexclu = new System.Windows.Forms.Label();
            this.labelsalepriceamount = new System.Windows.Forms.Label();
            this.labelpurchaseprice = new System.Windows.Forms.Label();
            this.labelsaleprice = new System.Windows.Forms.Label();
            this.iconBtnadjustitem = new FontAwesome.Sharp.IconButton();
            this.iconBtnitemname = new FontAwesome.Sharp.IconButton();
            this.paneltransaction = new System.Windows.Forms.Panel();
            this.paneltype = new System.Windows.Forms.Panel();
            this.iconBtntype = new FontAwesome.Sharp.IconButton();
            this.iconBtnname = new FontAwesome.Sharp.IconButton();
            this.iconBtndate = new FontAwesome.Sharp.IconButton();
            this.iconBtnqty = new FontAwesome.Sharp.IconButton();
            this.iconBtnprice = new FontAwesome.Sharp.IconButton();
            this.iconBtnstatus = new FontAwesome.Sharp.IconButton();
            this.panelsearch = new System.Windows.Forms.Panel();
            this.iconPicturesearch = new FontAwesome.Sharp.IconPictureBox();
            this.textBoxsearch = new System.Windows.Forms.TextBox();
            this.labeltransaction = new System.Windows.Forms.Label();
            this.paneladditems.SuspendLayout();
            this.paneladditem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPicsearch)).BeginInit();
            this.paneladjustitem.SuspendLayout();
            this.paneltransaction.SuspendLayout();
            this.paneltype.SuspendLayout();
            this.panelsearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPicturesearch)).BeginInit();
            this.SuspendLayout();
            // 
            // paneladditems
            // 
            this.paneladditems.BackColor = System.Drawing.Color.White;
            this.paneladditems.Controls.Add(this.paneladditem);
            this.paneladditems.Dock = System.Windows.Forms.DockStyle.Left;
            this.paneladditems.Location = new System.Drawing.Point(0, 0);
            this.paneladditems.Name = "paneladditems";
            this.paneladditems.Size = new System.Drawing.Size(234, 488);
            this.paneladditems.TabIndex = 0;
            // 
            // paneladditem
            // 
            this.paneladditem.Controls.Add(this.iconBtnquantity);
            this.paneladditem.Controls.Add(this.iconBtnitem);
            this.paneladditem.Controls.Add(this.iconBtndropdown);
            this.paneladditem.Controls.Add(this.iconBtnadditems);
            this.paneladditem.Controls.Add(this.iconPicsearch);
            this.paneladditem.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneladditem.Location = new System.Drawing.Point(0, 0);
            this.paneladditem.Name = "paneladditem";
            this.paneladditem.Size = new System.Drawing.Size(234, 106);
            this.paneladditem.TabIndex = 0;
            // 
            // iconBtnquantity
            // 
            this.iconBtnquantity.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnquantity.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnquantity.IconChar = FontAwesome.Sharp.IconChar.ArrowDown;
            this.iconBtnquantity.IconColor = System.Drawing.Color.DarkRed;
            this.iconBtnquantity.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnquantity.IconSize = 30;
            this.iconBtnquantity.Location = new System.Drawing.Point(100, 65);
            this.iconBtnquantity.Name = "iconBtnquantity";
            this.iconBtnquantity.Size = new System.Drawing.Size(116, 32);
            this.iconBtnquantity.TabIndex = 4;
            this.iconBtnquantity.Text = "QUANTITY";
            this.iconBtnquantity.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnquantity.UseVisualStyleBackColor = true;
            // 
            // iconBtnitem
            // 
            this.iconBtnitem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnitem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnitem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnitem.IconChar = FontAwesome.Sharp.IconChar.ArrowDown;
            this.iconBtnitem.IconColor = System.Drawing.Color.DarkRed;
            this.iconBtnitem.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnitem.IconSize = 30;
            this.iconBtnitem.Location = new System.Drawing.Point(4, 65);
            this.iconBtnitem.Name = "iconBtnitem";
            this.iconBtnitem.Size = new System.Drawing.Size(90, 32);
            this.iconBtnitem.TabIndex = 3;
            this.iconBtnitem.Text = "ITEM";
            this.iconBtnitem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnitem.UseVisualStyleBackColor = true;
            // 
            // iconBtndropdown
            // 
            this.iconBtndropdown.BackColor = System.Drawing.Color.Goldenrod;
            this.iconBtndropdown.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtndropdown.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconBtndropdown.IconChar = FontAwesome.Sharp.IconChar.AngleDown;
            this.iconBtndropdown.IconColor = System.Drawing.Color.White;
            this.iconBtndropdown.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtndropdown.IconSize = 30;
            this.iconBtndropdown.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.iconBtndropdown.Location = new System.Drawing.Point(172, 10);
            this.iconBtndropdown.Name = "iconBtndropdown";
            this.iconBtndropdown.Size = new System.Drawing.Size(31, 32);
            this.iconBtndropdown.TabIndex = 2;
            this.iconBtndropdown.UseVisualStyleBackColor = false;
            // 
            // iconBtnadditems
            // 
            this.iconBtnadditems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.iconBtnadditems.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnadditems.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconBtnadditems.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnadditems.ForeColor = System.Drawing.Color.White;
            this.iconBtnadditems.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.iconBtnadditems.IconColor = System.Drawing.Color.White;
            this.iconBtnadditems.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnadditems.IconSize = 30;
            this.iconBtnadditems.Location = new System.Drawing.Point(69, 10);
            this.iconBtnadditems.Name = "iconBtnadditems";
            this.iconBtnadditems.Size = new System.Drawing.Size(106, 32);
            this.iconBtnadditems.TabIndex = 1;
            this.iconBtnadditems.Text = "Add Items";
            this.iconBtnadditems.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnadditems.UseVisualStyleBackColor = false;
            // 
            // iconPicsearch
            // 
            this.iconPicsearch.BackColor = System.Drawing.Color.Silver;
            this.iconPicsearch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPicsearch.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconPicsearch.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPicsearch.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPicsearch.Location = new System.Drawing.Point(13, 10);
            this.iconPicsearch.Name = "iconPicsearch";
            this.iconPicsearch.Size = new System.Drawing.Size(32, 32);
            this.iconPicsearch.TabIndex = 0;
            this.iconPicsearch.TabStop = false;
            // 
            // paneladjustitem
            // 
            this.paneladjustitem.BackColor = System.Drawing.Color.White;
            this.paneladjustitem.Controls.Add(this.labelstockvalueamount);
            this.paneladjustitem.Controls.Add(this.labelstockqtyamount);
            this.paneladjustitem.Controls.Add(this.labelstockvalue);
            this.paneladjustitem.Controls.Add(this.labelstockquantity);
            this.paneladjustitem.Controls.Add(this.labelexcl);
            this.paneladjustitem.Controls.Add(this.labelpurpriceamount);
            this.paneladjustitem.Controls.Add(this.labelexclu);
            this.paneladjustitem.Controls.Add(this.labelsalepriceamount);
            this.paneladjustitem.Controls.Add(this.labelpurchaseprice);
            this.paneladjustitem.Controls.Add(this.labelsaleprice);
            this.paneladjustitem.Controls.Add(this.iconBtnadjustitem);
            this.paneladjustitem.Controls.Add(this.iconBtnitemname);
            this.paneladjustitem.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneladjustitem.Location = new System.Drawing.Point(234, 0);
            this.paneladjustitem.Name = "paneladjustitem";
            this.paneladjustitem.Size = new System.Drawing.Size(715, 132);
            this.paneladjustitem.TabIndex = 1;
            // 
            // labelstockvalueamount
            // 
            this.labelstockvalueamount.AutoSize = true;
            this.labelstockvalueamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelstockvalueamount.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.labelstockvalueamount.Location = new System.Drawing.Point(665, 101);
            this.labelstockvalueamount.Name = "labelstockvalueamount";
            this.labelstockvalueamount.Size = new System.Drawing.Size(42, 15);
            this.labelstockvalueamount.TabIndex = 15;
            this.labelstockvalueamount.Text = "Rs 0.0";
            // 
            // labelstockqtyamount
            // 
            this.labelstockqtyamount.AutoSize = true;
            this.labelstockqtyamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelstockqtyamount.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.labelstockqtyamount.Location = new System.Drawing.Point(692, 75);
            this.labelstockqtyamount.Name = "labelstockqtyamount";
            this.labelstockqtyamount.Size = new System.Drawing.Size(14, 15);
            this.labelstockqtyamount.TabIndex = 14;
            this.labelstockqtyamount.Text = "0";
            // 
            // labelstockvalue
            // 
            this.labelstockvalue.AutoSize = true;
            this.labelstockvalue.Location = new System.Drawing.Point(580, 103);
            this.labelstockvalue.Name = "labelstockvalue";
            this.labelstockvalue.Size = new System.Drawing.Size(84, 13);
            this.labelstockvalue.TabIndex = 13;
            this.labelstockvalue.Text = "STOCK VALUE:";
            // 
            // labelstockquantity
            // 
            this.labelstockquantity.AutoSize = true;
            this.labelstockquantity.Location = new System.Drawing.Point(580, 75);
            this.labelstockquantity.Name = "labelstockquantity";
            this.labelstockquantity.Size = new System.Drawing.Size(104, 13);
            this.labelstockquantity.TabIndex = 12;
            this.labelstockquantity.Text = "STOCK QUANTITY:";
            // 
            // labelexcl
            // 
            this.labelexcl.AutoSize = true;
            this.labelexcl.Location = new System.Drawing.Point(166, 93);
            this.labelexcl.Name = "labelexcl";
            this.labelexcl.Size = new System.Drawing.Size(32, 13);
            this.labelexcl.TabIndex = 11;
            this.labelexcl.Text = "(excl)";
            // 
            // labelpurpriceamount
            // 
            this.labelpurpriceamount.AutoSize = true;
            this.labelpurpriceamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpurpriceamount.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.labelpurpriceamount.Location = new System.Drawing.Point(115, 91);
            this.labelpurpriceamount.Name = "labelpurpriceamount";
            this.labelpurpriceamount.Size = new System.Drawing.Size(49, 15);
            this.labelpurpriceamount.TabIndex = 10;
            this.labelpurpriceamount.Text = "Rs 9.50";
            // 
            // labelexclu
            // 
            this.labelexclu.AutoSize = true;
            this.labelexclu.Location = new System.Drawing.Point(144, 65);
            this.labelexclu.Name = "labelexclu";
            this.labelexclu.Size = new System.Drawing.Size(32, 13);
            this.labelexclu.TabIndex = 9;
            this.labelexclu.Text = "(excl)";
            // 
            // labelsalepriceamount
            // 
            this.labelsalepriceamount.AutoSize = true;
            this.labelsalepriceamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsalepriceamount.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.labelsalepriceamount.Location = new System.Drawing.Point(84, 63);
            this.labelsalepriceamount.Name = "labelsalepriceamount";
            this.labelsalepriceamount.Size = new System.Drawing.Size(56, 15);
            this.labelsalepriceamount.TabIndex = 8;
            this.labelsalepriceamount.Text = "Rs 10.00";
            // 
            // labelpurchaseprice
            // 
            this.labelpurchaseprice.AutoSize = true;
            this.labelpurchaseprice.Location = new System.Drawing.Point(15, 93);
            this.labelpurchaseprice.Name = "labelpurchaseprice";
            this.labelpurchaseprice.Size = new System.Drawing.Size(104, 13);
            this.labelpurchaseprice.TabIndex = 7;
            this.labelpurchaseprice.Text = "PURCHASE PRICE:";
            // 
            // labelsaleprice
            // 
            this.labelsaleprice.AutoSize = true;
            this.labelsaleprice.Location = new System.Drawing.Point(15, 65);
            this.labelsaleprice.Name = "labelsaleprice";
            this.labelsaleprice.Size = new System.Drawing.Size(72, 13);
            this.labelsaleprice.TabIndex = 6;
            this.labelsaleprice.Text = "SALE PRICE:";
            // 
            // iconBtnadjustitem
            // 
            this.iconBtnadjustitem.BackColor = System.Drawing.Color.Blue;
            this.iconBtnadjustitem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnadjustitem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnadjustitem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnadjustitem.ForeColor = System.Drawing.Color.White;
            this.iconBtnadjustitem.IconChar = FontAwesome.Sharp.IconChar.SlidersH;
            this.iconBtnadjustitem.IconColor = System.Drawing.Color.White;
            this.iconBtnadjustitem.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnadjustitem.IconSize = 30;
            this.iconBtnadjustitem.Location = new System.Drawing.Point(583, 10);
            this.iconBtnadjustitem.Name = "iconBtnadjustitem";
            this.iconBtnadjustitem.Size = new System.Drawing.Size(130, 32);
            this.iconBtnadjustitem.TabIndex = 5;
            this.iconBtnadjustitem.Text = "ADJUST ITEM";
            this.iconBtnadjustitem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnadjustitem.UseVisualStyleBackColor = false;
            // 
            // iconBtnitemname
            // 
            this.iconBtnitemname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnitemname.Flip = FontAwesome.Sharp.FlipOrientation.Horizontal;
            this.iconBtnitemname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnitemname.IconChar = FontAwesome.Sharp.IconChar.Reply;
            this.iconBtnitemname.IconColor = System.Drawing.Color.Black;
            this.iconBtnitemname.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnitemname.IconSize = 30;
            this.iconBtnitemname.Location = new System.Drawing.Point(18, 10);
            this.iconBtnitemname.Name = "iconBtnitemname";
            this.iconBtnitemname.Size = new System.Drawing.Size(106, 32);
            this.iconBtnitemname.TabIndex = 0;
            this.iconBtnitemname.Text = "ItemName";
            this.iconBtnitemname.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnitemname.UseVisualStyleBackColor = true;
            // 
            // paneltransaction
            // 
            this.paneltransaction.BackColor = System.Drawing.Color.White;
            this.paneltransaction.Controls.Add(this.paneltype);
            this.paneltransaction.Controls.Add(this.panelsearch);
            this.paneltransaction.Dock = System.Windows.Forms.DockStyle.Fill;
            this.paneltransaction.Location = new System.Drawing.Point(234, 132);
            this.paneltransaction.Name = "paneltransaction";
            this.paneltransaction.Size = new System.Drawing.Size(715, 356);
            this.paneltransaction.TabIndex = 2;
            // 
            // paneltype
            // 
            this.paneltype.Controls.Add(this.iconBtntype);
            this.paneltype.Controls.Add(this.iconBtnname);
            this.paneltype.Controls.Add(this.iconBtndate);
            this.paneltype.Controls.Add(this.iconBtnqty);
            this.paneltype.Controls.Add(this.iconBtnprice);
            this.paneltype.Controls.Add(this.iconBtnstatus);
            this.paneltype.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneltype.Location = new System.Drawing.Point(0, 54);
            this.paneltype.Name = "paneltype";
            this.paneltype.Size = new System.Drawing.Size(715, 40);
            this.paneltype.TabIndex = 1;
            // 
            // iconBtntype
            // 
            this.iconBtntype.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtntype.Dock = System.Windows.Forms.DockStyle.Fill;
            this.iconBtntype.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtntype.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtntype.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtntype.IconColor = System.Drawing.Color.Black;
            this.iconBtntype.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtntype.IconSize = 25;
            this.iconBtntype.Location = new System.Drawing.Point(0, 0);
            this.iconBtntype.Name = "iconBtntype";
            this.iconBtntype.Size = new System.Drawing.Size(118, 40);
            this.iconBtntype.TabIndex = 4;
            this.iconBtntype.Text = "TYPE";
            this.iconBtntype.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtntype.UseVisualStyleBackColor = true;
            // 
            // iconBtnname
            // 
            this.iconBtnname.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnname.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtnname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnname.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtnname.IconColor = System.Drawing.Color.Black;
            this.iconBtnname.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnname.IconSize = 25;
            this.iconBtnname.Location = new System.Drawing.Point(118, 0);
            this.iconBtnname.Name = "iconBtnname";
            this.iconBtnname.Size = new System.Drawing.Size(158, 40);
            this.iconBtnname.TabIndex = 4;
            this.iconBtnname.Text = "NAME";
            this.iconBtnname.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnname.UseVisualStyleBackColor = true;
            // 
            // iconBtndate
            // 
            this.iconBtndate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtndate.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtndate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtndate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtndate.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtndate.IconColor = System.Drawing.Color.Black;
            this.iconBtndate.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtndate.IconSize = 25;
            this.iconBtndate.Location = new System.Drawing.Point(276, 0);
            this.iconBtndate.Name = "iconBtndate";
            this.iconBtndate.Size = new System.Drawing.Size(107, 40);
            this.iconBtndate.TabIndex = 3;
            this.iconBtndate.Text = "DATE";
            this.iconBtndate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtndate.UseVisualStyleBackColor = true;
            // 
            // iconBtnqty
            // 
            this.iconBtnqty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnqty.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtnqty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnqty.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtnqty.IconColor = System.Drawing.Color.Black;
            this.iconBtnqty.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnqty.IconSize = 25;
            this.iconBtnqty.Location = new System.Drawing.Point(383, 0);
            this.iconBtnqty.Name = "iconBtnqty";
            this.iconBtnqty.Size = new System.Drawing.Size(110, 40);
            this.iconBtnqty.TabIndex = 3;
            this.iconBtnqty.Text = "QUANTITY";
            this.iconBtnqty.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnqty.UseVisualStyleBackColor = true;
            // 
            // iconBtnprice
            // 
            this.iconBtnprice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnprice.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtnprice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnprice.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtnprice.IconColor = System.Drawing.Color.Black;
            this.iconBtnprice.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnprice.IconSize = 25;
            this.iconBtnprice.Location = new System.Drawing.Point(493, 0);
            this.iconBtnprice.Name = "iconBtnprice";
            this.iconBtnprice.Size = new System.Drawing.Size(116, 40);
            this.iconBtnprice.TabIndex = 2;
            this.iconBtnprice.Text = "PRICE/UNIT";
            this.iconBtnprice.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnprice.UseVisualStyleBackColor = true;
            // 
            // iconBtnstatus
            // 
            this.iconBtnstatus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnstatus.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtnstatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnstatus.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtnstatus.IconColor = System.Drawing.Color.Black;
            this.iconBtnstatus.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnstatus.IconSize = 25;
            this.iconBtnstatus.Location = new System.Drawing.Point(609, 0);
            this.iconBtnstatus.Name = "iconBtnstatus";
            this.iconBtnstatus.Size = new System.Drawing.Size(106, 40);
            this.iconBtnstatus.TabIndex = 1;
            this.iconBtnstatus.Text = "STATUS";
            this.iconBtnstatus.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnstatus.UseVisualStyleBackColor = true;
            // 
            // panelsearch
            // 
            this.panelsearch.Controls.Add(this.iconPicturesearch);
            this.panelsearch.Controls.Add(this.textBoxsearch);
            this.panelsearch.Controls.Add(this.labeltransaction);
            this.panelsearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelsearch.Location = new System.Drawing.Point(0, 0);
            this.panelsearch.Name = "panelsearch";
            this.panelsearch.Size = new System.Drawing.Size(715, 54);
            this.panelsearch.TabIndex = 0;
            // 
            // iconPicturesearch
            // 
            this.iconPicturesearch.BackColor = System.Drawing.Color.White;
            this.iconPicturesearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.iconPicturesearch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPicturesearch.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconPicturesearch.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPicturesearch.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPicturesearch.IconSize = 24;
            this.iconPicturesearch.Location = new System.Drawing.Point(475, 11);
            this.iconPicturesearch.Name = "iconPicturesearch";
            this.iconPicturesearch.Size = new System.Drawing.Size(24, 25);
            this.iconPicturesearch.TabIndex = 1;
            this.iconPicturesearch.TabStop = false;
            // 
            // textBoxsearch
            // 
            this.textBoxsearch.Location = new System.Drawing.Point(499, 11);
            this.textBoxsearch.Multiline = true;
            this.textBoxsearch.Name = "textBoxsearch";
            this.textBoxsearch.Size = new System.Drawing.Size(166, 25);
            this.textBoxsearch.TabIndex = 1;
            // 
            // labeltransaction
            // 
            this.labeltransaction.AutoSize = true;
            this.labeltransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltransaction.Location = new System.Drawing.Point(6, 20);
            this.labeltransaction.Name = "labeltransaction";
            this.labeltransaction.Size = new System.Drawing.Size(116, 16);
            this.labeltransaction.TabIndex = 0;
            this.labeltransaction.Text = "TRANSACTION";
            // 
            // addproductitems
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.paneltransaction);
            this.Controls.Add(this.paneladjustitem);
            this.Controls.Add(this.paneladditems);
            this.Name = "addproductitems";
            this.Size = new System.Drawing.Size(949, 488);
            this.paneladditems.ResumeLayout(false);
            this.paneladditem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconPicsearch)).EndInit();
            this.paneladjustitem.ResumeLayout(false);
            this.paneladjustitem.PerformLayout();
            this.paneltransaction.ResumeLayout(false);
            this.paneltype.ResumeLayout(false);
            this.panelsearch.ResumeLayout(false);
            this.panelsearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPicturesearch)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel paneladditems;
        private FontAwesome.Sharp.IconPictureBox iconPicsearch;
        private System.Windows.Forms.Panel paneladjustitem;
        private System.Windows.Forms.Panel paneltransaction;
        private FontAwesome.Sharp.IconButton iconBtndropdown;
        private FontAwesome.Sharp.IconButton iconBtnadditems;
        private System.Windows.Forms.Panel paneladditem;
        private FontAwesome.Sharp.IconButton iconBtnquantity;
        private FontAwesome.Sharp.IconButton iconBtnitem;
        private System.Windows.Forms.Label labelstockvalueamount;
        private System.Windows.Forms.Label labelstockqtyamount;
        private System.Windows.Forms.Label labelstockvalue;
        private System.Windows.Forms.Label labelstockquantity;
        private System.Windows.Forms.Label labelexcl;
        private System.Windows.Forms.Label labelpurpriceamount;
        private System.Windows.Forms.Label labelexclu;
        private System.Windows.Forms.Label labelsalepriceamount;
        private System.Windows.Forms.Label labelpurchaseprice;
        private System.Windows.Forms.Label labelsaleprice;
        private FontAwesome.Sharp.IconButton iconBtnadjustitem;
        private FontAwesome.Sharp.IconButton iconBtnitemname;
        private System.Windows.Forms.Panel panelsearch;
        private FontAwesome.Sharp.IconPictureBox iconPicturesearch;
        private System.Windows.Forms.TextBox textBoxsearch;
        private System.Windows.Forms.Label labeltransaction;
        private System.Windows.Forms.Panel paneltype;
        private FontAwesome.Sharp.IconButton iconBtntype;
        private FontAwesome.Sharp.IconButton iconBtnname;
        private FontAwesome.Sharp.IconButton iconBtndate;
        private FontAwesome.Sharp.IconButton iconBtnqty;
        private FontAwesome.Sharp.IconButton iconBtnprice;
        private FontAwesome.Sharp.IconButton iconBtnstatus;
    }
}
