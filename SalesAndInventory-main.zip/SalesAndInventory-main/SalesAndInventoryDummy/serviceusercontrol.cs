﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesAndInventoryDummy
{
    public partial class serviceusercontrol : UserControl
    {
        public serviceusercontrol()
        {
            InitializeComponent();
        }

        private void iconButton2_Click(object sender, EventArgs e)
        {

        }

        private void paneltranfill_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
