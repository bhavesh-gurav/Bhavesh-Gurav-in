﻿namespace SalesAndInventoryDummy
{
    partial class addnewunitusercontrol
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelmain = new System.Windows.Forms.Panel();
            this.panelunitsave = new System.Windows.Forms.Panel();
            this.buttonsave = new System.Windows.Forms.Button();
            this.buttonsavenew = new System.Windows.Forms.Button();
            this.panelunitname = new System.Windows.Forms.Panel();
            this.textBoxshortname = new System.Windows.Forms.TextBox();
            this.labelshortname = new System.Windows.Forms.Label();
            this.textBoxunitname = new System.Windows.Forms.TextBox();
            this.labelunitname = new System.Windows.Forms.Label();
            this.panelnewitems = new System.Windows.Forms.Panel();
            this.labelnewunit = new System.Windows.Forms.Label();
            this.iconButton1 = new FontAwesome.Sharp.IconButton();
            this.panelmain.SuspendLayout();
            this.panelunitsave.SuspendLayout();
            this.panelunitname.SuspendLayout();
            this.panelnewitems.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelmain
            // 
            this.panelmain.BackColor = System.Drawing.Color.White;
            this.panelmain.Controls.Add(this.panelunitsave);
            this.panelmain.Controls.Add(this.panelunitname);
            this.panelmain.Controls.Add(this.panelnewitems);
            this.panelmain.Location = new System.Drawing.Point(102, 3);
            this.panelmain.Name = "panelmain";
            this.panelmain.Size = new System.Drawing.Size(718, 198);
            this.panelmain.TabIndex = 0;
            // 
            // panelunitsave
            // 
            this.panelunitsave.Controls.Add(this.buttonsave);
            this.panelunitsave.Controls.Add(this.buttonsavenew);
            this.panelunitsave.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelunitsave.Location = new System.Drawing.Point(0, 114);
            this.panelunitsave.Name = "panelunitsave";
            this.panelunitsave.Size = new System.Drawing.Size(718, 46);
            this.panelunitsave.TabIndex = 2;
            // 
            // buttonsave
            // 
            this.buttonsave.BackColor = System.Drawing.Color.Blue;
            this.buttonsave.Dock = System.Windows.Forms.DockStyle.Right;
            this.buttonsave.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsave.ForeColor = System.Drawing.Color.White;
            this.buttonsave.Location = new System.Drawing.Point(476, 0);
            this.buttonsave.Name = "buttonsave";
            this.buttonsave.Size = new System.Drawing.Size(121, 46);
            this.buttonsave.TabIndex = 1;
            this.buttonsave.Text = "SAVE";
            this.buttonsave.UseVisualStyleBackColor = false;
            this.buttonsave.Click += new System.EventHandler(this.buttonsave_Click_1);
            // 
            // buttonsavenew
            // 
            this.buttonsavenew.BackColor = System.Drawing.Color.Blue;
            this.buttonsavenew.Dock = System.Windows.Forms.DockStyle.Right;
            this.buttonsavenew.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsavenew.ForeColor = System.Drawing.Color.White;
            this.buttonsavenew.Location = new System.Drawing.Point(597, 0);
            this.buttonsavenew.Name = "buttonsavenew";
            this.buttonsavenew.Size = new System.Drawing.Size(121, 46);
            this.buttonsavenew.TabIndex = 0;
            this.buttonsavenew.Text = "SAVE NEW";
            this.buttonsavenew.UseVisualStyleBackColor = false;
            // 
            // panelunitname
            // 
            this.panelunitname.Controls.Add(this.textBoxshortname);
            this.panelunitname.Controls.Add(this.labelshortname);
            this.panelunitname.Controls.Add(this.textBoxunitname);
            this.panelunitname.Controls.Add(this.labelunitname);
            this.panelunitname.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelunitname.Location = new System.Drawing.Point(0, 50);
            this.panelunitname.Name = "panelunitname";
            this.panelunitname.Size = new System.Drawing.Size(718, 64);
            this.panelunitname.TabIndex = 1;
            // 
            // textBoxshortname
            // 
            this.textBoxshortname.Location = new System.Drawing.Point(550, 18);
            this.textBoxshortname.Name = "textBoxshortname";
            this.textBoxshortname.Size = new System.Drawing.Size(145, 20);
            this.textBoxshortname.TabIndex = 3;
            // 
            // labelshortname
            // 
            this.labelshortname.AutoSize = true;
            this.labelshortname.Location = new System.Drawing.Point(463, 21);
            this.labelshortname.Name = "labelshortname";
            this.labelshortname.Size = new System.Drawing.Size(79, 13);
            this.labelshortname.TabIndex = 2;
            this.labelshortname.Text = "SHORT NAME";
            // 
            // textBoxunitname
            // 
            this.textBoxunitname.Location = new System.Drawing.Point(97, 18);
            this.textBoxunitname.Name = "textBoxunitname";
            this.textBoxunitname.Size = new System.Drawing.Size(328, 20);
            this.textBoxunitname.TabIndex = 1;
            // 
            // labelunitname
            // 
            this.labelunitname.AutoSize = true;
            this.labelunitname.Location = new System.Drawing.Point(24, 22);
            this.labelunitname.Name = "labelunitname";
            this.labelunitname.Size = new System.Drawing.Size(67, 13);
            this.labelunitname.TabIndex = 0;
            this.labelunitname.Text = "UNIT NAME";
            // 
            // panelnewitems
            // 
            this.panelnewitems.Controls.Add(this.labelnewunit);
            this.panelnewitems.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelnewitems.Location = new System.Drawing.Point(0, 0);
            this.panelnewitems.Name = "panelnewitems";
            this.panelnewitems.Size = new System.Drawing.Size(718, 50);
            this.panelnewitems.TabIndex = 0;
            this.panelnewitems.Paint += new System.Windows.Forms.PaintEventHandler(this.panelnewitems_Paint);
            // 
            // labelnewunit
            // 
            this.labelnewunit.AutoSize = true;
            this.labelnewunit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnewunit.Location = new System.Drawing.Point(23, 16);
            this.labelnewunit.Name = "labelnewunit";
            this.labelnewunit.Size = new System.Drawing.Size(81, 20);
            this.labelnewunit.TabIndex = 0;
            this.labelnewunit.Text = "New Unit";
            // 
            // iconButton1
            // 
            this.iconButton1.IconChar = FontAwesome.Sharp.IconChar.TimesCircle;
            this.iconButton1.IconColor = System.Drawing.Color.Black;
            this.iconButton1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButton1.IconSize = 40;
            this.iconButton1.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.iconButton1.Location = new System.Drawing.Point(842, 0);
            this.iconButton1.Name = "iconButton1";
            this.iconButton1.Size = new System.Drawing.Size(37, 39);
            this.iconButton1.TabIndex = 1;
            this.iconButton1.UseVisualStyleBackColor = true;
            // 
            // addnewunitusercontrol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.iconButton1);
            this.Controls.Add(this.panelmain);
            this.Name = "addnewunitusercontrol";
            this.Size = new System.Drawing.Size(879, 398);
            this.Load += new System.EventHandler(this.addnewunitusercontrol_Load);
            this.panelmain.ResumeLayout(false);
            this.panelunitsave.ResumeLayout(false);
            this.panelunitname.ResumeLayout(false);
            this.panelunitname.PerformLayout();
            this.panelnewitems.ResumeLayout(false);
            this.panelnewitems.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelmain;
        private System.Windows.Forms.Panel panelnewitems;
        private System.Windows.Forms.Panel panelunitsave;
        private System.Windows.Forms.Button buttonsave;
        private System.Windows.Forms.Button buttonsavenew;
        private System.Windows.Forms.Panel panelunitname;
        private System.Windows.Forms.TextBox textBoxshortname;
        private System.Windows.Forms.Label labelshortname;
        private System.Windows.Forms.TextBox textBoxunitname;
        private System.Windows.Forms.Label labelunitname;
        private System.Windows.Forms.Label labelnewunit;
        private FontAwesome.Sharp.IconButton iconButton1;
    }
}
