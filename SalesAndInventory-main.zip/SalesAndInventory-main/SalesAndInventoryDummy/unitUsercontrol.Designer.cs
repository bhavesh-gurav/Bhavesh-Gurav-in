﻿namespace SalesAndInventoryDummy
{
    partial class unitUsercontrol
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelitems = new System.Windows.Forms.Panel();
            this.panelfullshortname = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.FullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ShortName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paneladditems = new System.Windows.Forms.Panel();
            this.iconpicturesearchunit = new FontAwesome.Sharp.IconPictureBox();
            this.iconBtnaddunits = new FontAwesome.Sharp.IconButton();
            this.panelbags = new System.Windows.Forms.Panel();
            this.buttonaddconversion = new System.Windows.Forms.Button();
            this.labelbags = new System.Windows.Forms.Label();
            this.panelunits = new System.Windows.Forms.Panel();
            this.iconPicunitsearch = new FontAwesome.Sharp.IconPictureBox();
            this.labelunits = new System.Windows.Forms.Label();
            this.textBoxunitsearch = new System.Windows.Forms.TextBox();
            this.panelfill = new System.Windows.Forms.Panel();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.panelitems.SuspendLayout();
            this.panelfullshortname.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.paneladditems.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconpicturesearchunit)).BeginInit();
            this.panelbags.SuspendLayout();
            this.panelunits.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPicunitsearch)).BeginInit();
            this.panelfill.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelitems
            // 
            this.panelitems.BackColor = System.Drawing.Color.White;
            this.panelitems.Controls.Add(this.panelfullshortname);
            this.panelitems.Controls.Add(this.paneladditems);
            this.panelitems.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelitems.Location = new System.Drawing.Point(0, 0);
            this.panelitems.Name = "panelitems";
            this.panelitems.Size = new System.Drawing.Size(250, 476);
            this.panelitems.TabIndex = 0;
            this.panelitems.Paint += new System.Windows.Forms.PaintEventHandler(this.panelitems_Paint);
            // 
            // panelfullshortname
            // 
            this.panelfullshortname.Controls.Add(this.dataGridView1);
            this.panelfullshortname.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelfullshortname.Location = new System.Drawing.Point(0, 64);
            this.panelfullshortname.Name = "panelfullshortname";
            this.panelfullshortname.Size = new System.Drawing.Size(250, 334);
            this.panelfullshortname.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FullName,
            this.ShortName});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView1.Location = new System.Drawing.Point(0, 0);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(250, 245);
            this.dataGridView1.TabIndex = 6;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // FullName
            // 
            this.FullName.HeaderText = "Full Name";
            this.FullName.Name = "FullName";
            // 
            // ShortName
            // 
            this.ShortName.HeaderText = "Short Name";
            this.ShortName.Name = "ShortName";
            // 
            // paneladditems
            // 
            this.paneladditems.Controls.Add(this.iconpicturesearchunit);
            this.paneladditems.Controls.Add(this.iconBtnaddunits);
            this.paneladditems.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneladditems.Location = new System.Drawing.Point(0, 0);
            this.paneladditems.Name = "paneladditems";
            this.paneladditems.Size = new System.Drawing.Size(250, 64);
            this.paneladditems.TabIndex = 0;
            // 
            // iconpicturesearchunit
            // 
            this.iconpicturesearchunit.BackColor = System.Drawing.Color.Silver;
            this.iconpicturesearchunit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconpicturesearchunit.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconpicturesearchunit.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconpicturesearchunit.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconpicturesearchunit.Location = new System.Drawing.Point(20, 11);
            this.iconpicturesearchunit.Name = "iconpicturesearchunit";
            this.iconpicturesearchunit.Size = new System.Drawing.Size(32, 32);
            this.iconpicturesearchunit.TabIndex = 6;
            this.iconpicturesearchunit.TabStop = false;
            // 
            // iconBtnaddunits
            // 
            this.iconBtnaddunits.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.iconBtnaddunits.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconBtnaddunits.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnaddunits.ForeColor = System.Drawing.Color.White;
            this.iconBtnaddunits.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.iconBtnaddunits.IconColor = System.Drawing.Color.White;
            this.iconBtnaddunits.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnaddunits.IconSize = 30;
            this.iconBtnaddunits.Location = new System.Drawing.Point(85, 11);
            this.iconBtnaddunits.Name = "iconBtnaddunits";
            this.iconBtnaddunits.Size = new System.Drawing.Size(121, 32);
            this.iconBtnaddunits.TabIndex = 5;
            this.iconBtnaddunits.Text = "Add Units";
            this.iconBtnaddunits.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnaddunits.UseVisualStyleBackColor = false;
            this.iconBtnaddunits.Click += new System.EventHandler(this.iconBtnaddunits_Click);
            // 
            // panelbags
            // 
            this.panelbags.BackColor = System.Drawing.Color.White;
            this.panelbags.Controls.Add(this.buttonaddconversion);
            this.panelbags.Controls.Add(this.labelbags);
            this.panelbags.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelbags.Location = new System.Drawing.Point(250, 0);
            this.panelbags.Name = "panelbags";
            this.panelbags.Size = new System.Drawing.Size(673, 52);
            this.panelbags.TabIndex = 1;
            this.panelbags.Paint += new System.Windows.Forms.PaintEventHandler(this.panelbags_Paint);
            // 
            // buttonaddconversion
            // 
            this.buttonaddconversion.BackColor = System.Drawing.Color.Blue;
            this.buttonaddconversion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonaddconversion.ForeColor = System.Drawing.Color.White;
            this.buttonaddconversion.Location = new System.Drawing.Point(544, 1);
            this.buttonaddconversion.Name = "buttonaddconversion";
            this.buttonaddconversion.Size = new System.Drawing.Size(129, 52);
            this.buttonaddconversion.TabIndex = 3;
            this.buttonaddconversion.Text = "Add Conversion";
            this.buttonaddconversion.UseVisualStyleBackColor = false;
            // 
            // labelbags
            // 
            this.labelbags.AutoSize = true;
            this.labelbags.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelbags.Location = new System.Drawing.Point(15, 13);
            this.labelbags.Name = "labelbags";
            this.labelbags.Size = new System.Drawing.Size(49, 16);
            this.labelbags.TabIndex = 2;
            this.labelbags.Text = "BAGS";
            // 
            // panelunits
            // 
            this.panelunits.BackColor = System.Drawing.Color.White;
            this.panelunits.Controls.Add(this.iconPicunitsearch);
            this.panelunits.Controls.Add(this.labelunits);
            this.panelunits.Controls.Add(this.textBoxunitsearch);
            this.panelunits.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelunits.Location = new System.Drawing.Point(250, 52);
            this.panelunits.Name = "panelunits";
            this.panelunits.Size = new System.Drawing.Size(673, 44);
            this.panelunits.TabIndex = 2;
            // 
            // iconPicunitsearch
            // 
            this.iconPicunitsearch.BackColor = System.Drawing.Color.White;
            this.iconPicunitsearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.iconPicunitsearch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPicunitsearch.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconPicunitsearch.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPicunitsearch.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPicunitsearch.IconSize = 24;
            this.iconPicunitsearch.Location = new System.Drawing.Point(480, 15);
            this.iconPicunitsearch.Name = "iconPicunitsearch";
            this.iconPicunitsearch.Size = new System.Drawing.Size(24, 25);
            this.iconPicunitsearch.TabIndex = 4;
            this.iconPicunitsearch.TabStop = false;
            // 
            // labelunits
            // 
            this.labelunits.AutoSize = true;
            this.labelunits.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelunits.Location = new System.Drawing.Point(10, 15);
            this.labelunits.Name = "labelunits";
            this.labelunits.Size = new System.Drawing.Size(54, 16);
            this.labelunits.TabIndex = 1;
            this.labelunits.Text = "UNITS";
            // 
            // textBoxunitsearch
            // 
            this.textBoxunitsearch.Location = new System.Drawing.Point(504, 15);
            this.textBoxunitsearch.Multiline = true;
            this.textBoxunitsearch.Name = "textBoxunitsearch";
            this.textBoxunitsearch.Size = new System.Drawing.Size(166, 25);
            this.textBoxunitsearch.TabIndex = 3;
            // 
            // panelfill
            // 
            this.panelfill.BackColor = System.Drawing.Color.White;
            this.panelfill.Controls.Add(this.dataGridView2);
            this.panelfill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelfill.Location = new System.Drawing.Point(250, 96);
            this.panelfill.Name = "panelfill";
            this.panelfill.Size = new System.Drawing.Size(673, 380);
            this.panelfill.TabIndex = 3;
            this.panelfill.Paint += new System.Windows.Forms.PaintEventHandler(this.panelfill_Paint);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView2.Location = new System.Drawing.Point(0, 0);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(673, 380);
            this.dataGridView2.TabIndex = 7;
            // 
            // unitUsercontrol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.Controls.Add(this.panelfill);
            this.Controls.Add(this.panelunits);
            this.Controls.Add(this.panelbags);
            this.Controls.Add(this.panelitems);
            this.Name = "unitUsercontrol";
            this.Size = new System.Drawing.Size(923, 476);
            this.Load += new System.EventHandler(this.unitUsercontrol_Load);
            this.panelitems.ResumeLayout(false);
            this.panelfullshortname.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.paneladditems.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconpicturesearchunit)).EndInit();
            this.panelbags.ResumeLayout(false);
            this.panelbags.PerformLayout();
            this.panelunits.ResumeLayout(false);
            this.panelunits.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPicunitsearch)).EndInit();
            this.panelfill.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelitems;
        private System.Windows.Forms.Panel panelbags;
        private System.Windows.Forms.Panel panelunits;
        private FontAwesome.Sharp.IconPictureBox iconPicunitsearch;
        private System.Windows.Forms.Label labelunits;
        private System.Windows.Forms.TextBox textBoxunitsearch;
        private System.Windows.Forms.Panel panelfill;
        private System.Windows.Forms.Panel paneladditems;
        private System.Windows.Forms.Button buttonaddconversion;
        private System.Windows.Forms.Label labelbags;
        private FontAwesome.Sharp.IconPictureBox iconpicturesearchunit;
        private FontAwesome.Sharp.IconButton iconBtnaddunits;
        private System.Windows.Forms.Panel panelfullshortname;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn FullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ShortName;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}
