﻿namespace SalesAndInventoryDummy
{
    partial class Items
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paneladjustitems = new System.Windows.Forms.Panel();
            this.buttonunits = new System.Windows.Forms.Button();
            this.buttonmyonlinestore = new System.Windows.Forms.Button();
            this.buttonproducts = new System.Windows.Forms.Button();
            this.buttonservices = new System.Windows.Forms.Button();
            this.panelfullfill = new System.Windows.Forms.Panel();
            this.paneladjustitems.SuspendLayout();
            this.SuspendLayout();
            // 
            // paneladjustitems
            // 
            this.paneladjustitems.Controls.Add(this.buttonunits);
            this.paneladjustitems.Controls.Add(this.buttonmyonlinestore);
            this.paneladjustitems.Controls.Add(this.buttonproducts);
            this.paneladjustitems.Controls.Add(this.buttonservices);
            this.paneladjustitems.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneladjustitems.Location = new System.Drawing.Point(0, 0);
            this.paneladjustitems.Name = "paneladjustitems";
            this.paneladjustitems.Size = new System.Drawing.Size(1121, 45);
            this.paneladjustitems.TabIndex = 1;
            // 
            // buttonunits
            // 
            this.buttonunits.Dock = System.Windows.Forms.DockStyle.Fill;
            this.buttonunits.Location = new System.Drawing.Point(817, 0);
            this.buttonunits.Name = "buttonunits";
            this.buttonunits.Size = new System.Drawing.Size(304, 45);
            this.buttonunits.TabIndex = 2;
            this.buttonunits.Text = "UNITS";
            this.buttonunits.UseVisualStyleBackColor = true;
            this.buttonunits.Click += new System.EventHandler(this.buttonunits_Click);
            // 
            // buttonmyonlinestore
            // 
            this.buttonmyonlinestore.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonmyonlinestore.Location = new System.Drawing.Point(554, 0);
            this.buttonmyonlinestore.Name = "buttonmyonlinestore";
            this.buttonmyonlinestore.Size = new System.Drawing.Size(263, 45);
            this.buttonmyonlinestore.TabIndex = 3;
            this.buttonmyonlinestore.Text = "MY ONLINE  STORE";
            this.buttonmyonlinestore.UseVisualStyleBackColor = true;
            this.buttonmyonlinestore.Click += new System.EventHandler(this.buttonmyonlinestore_Click);
            // 
            // buttonproducts
            // 
            this.buttonproducts.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonproducts.Location = new System.Drawing.Point(294, 0);
            this.buttonproducts.Name = "buttonproducts";
            this.buttonproducts.Size = new System.Drawing.Size(260, 45);
            this.buttonproducts.TabIndex = 0;
            this.buttonproducts.Text = "PRODUCTS";
            this.buttonproducts.UseVisualStyleBackColor = true;
            this.buttonproducts.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonservices
            // 
            this.buttonservices.Dock = System.Windows.Forms.DockStyle.Left;
            this.buttonservices.Location = new System.Drawing.Point(0, 0);
            this.buttonservices.Name = "buttonservices";
            this.buttonservices.Size = new System.Drawing.Size(294, 45);
            this.buttonservices.TabIndex = 1;
            this.buttonservices.Text = "SERVICES";
            this.buttonservices.UseVisualStyleBackColor = true;
            this.buttonservices.Click += new System.EventHandler(this.button2_Click);
            // 
            // panelfullfill
            // 
            this.panelfullfill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelfullfill.Location = new System.Drawing.Point(0, 45);
            this.panelfullfill.Name = "panelfullfill";
            this.panelfullfill.Size = new System.Drawing.Size(1121, 634);
            this.panelfullfill.TabIndex = 2;
            // 
            // Items
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelfullfill);
            this.Controls.Add(this.paneladjustitems);
            this.Name = "Items";
            this.Size = new System.Drawing.Size(1121, 679);
            this.paneladjustitems.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel paneladjustitems;
        private System.Windows.Forms.Panel panelfullfill;
        private System.Windows.Forms.Button buttonmyonlinestore;
        private System.Windows.Forms.Button buttonunits;
        private System.Windows.Forms.Button buttonservices;
        private System.Windows.Forms.Button buttonproducts;
    }
}
