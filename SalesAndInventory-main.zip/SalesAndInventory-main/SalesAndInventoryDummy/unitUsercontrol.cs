﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Configuration;
using databaseconnwampp;


namespace SalesAndInventoryDummy
{
    public partial class unitUsercontrol : UserControl
    {
        Dashboard db = new Dashboard();
        MySqlConnection con = null;
         
        private static unitUsercontrol _instance;
        private MySqlCommand cmd;
        public static unitUsercontrol Instance3
        {
              get
              {
                  if (_instance == null)
                      _instance = new unitUsercontrol();
                  return _instance;
              }
          }
        public unitUsercontrol()
        {
            InitializeComponent();
            con = dbconnwamp.connectdb();
          
        }
        public void dispdata()
        {
            try
            {
                
              // con.Open();
           /*    MySqlCommand comm = con.CreateCommand();
                comm.CommandType = CommandType.Text;
                comm.CommandText = "SELECT * FROM new_unit";
               // comm.Connection.Open();
                comm.ExecuteNonQuery();
                DataTable dt = new DataTable();
                MySqlDataAdapter da = new MySqlDataAdapter(comm);*/
                 
               con.Open();
               cmd = new MySqlCommand();
               cmd.Connection = con;
               cmd.CommandText = "SELECT * FROM new_unit";
               cmd.ExecuteNonQuery();
               DataTable dt = new DataTable();
               MySqlDataAdapter da = new MySqlDataAdapter(cmd);
                da.Fill(dt);
                dataGridView1.DataSource = dt;
                
                con.Close();
            }
            catch (MySqlException ex)
            {

            }
           //
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelitems_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panelfill_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void iconBtnaddunits_Click(object sender, EventArgs e)
        {
            
            if (!db.paneldesktopfull.Controls.Contains(addnewunitusercontrol.Instance4))
            {
                db.paneldesktopfull.Controls.Add(addnewunitusercontrol.Instance4);
                addnewunitusercontrol.Instance4.Dock = DockStyle.Fill;
                addnewunitusercontrol.Instance4.BringToFront();
            }
            else
                addnewunitusercontrol.Instance4.BringToFront();
        }

        private void panelbags_Paint(object sender, PaintEventArgs e)
        {

        }

        private void unitUsercontrol_Load(object sender, EventArgs e)
        {
            dispdata();
        }

        private void iconBtnconvesrion_Click(object sender, EventArgs e)
        {

        }
    }
}
