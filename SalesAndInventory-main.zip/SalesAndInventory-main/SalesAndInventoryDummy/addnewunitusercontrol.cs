﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using databaseconnwampp;

namespace SalesAndInventoryDummy
{ 
    public partial class addnewunitusercontrol : UserControl
    {
        MySqlConnection con = null;
       private static addnewunitusercontrol _instance;

        public static addnewunitusercontrol Instance4
        {
            get
            {
                if (_instance == null)
                    _instance = new addnewunitusercontrol();
                return _instance;
            }
        }
        public addnewunitusercontrol()
        {
            InitializeComponent();
            
            con = dbconnwamp.connectdb();
        }


        private void panelnewitems_Paint(object sender, PaintEventArgs e)
        {

        }

        private void addnewunitusercontrol_Load(object sender, EventArgs e)
        {

        }

       
            
      

        private void buttonsave_Click_1(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                string query = "INSERT INTO `new_unit`(`unit_name`, `short_name`) VALUES ('" + textBoxunitname.Text + "','" + textBoxshortname.Text + "')";
                MySqlCommand cmd = new MySqlCommand(query, con);
                cmd.ExecuteNonQuery();
                
                MessageBox.Show("Data inserted Successfully");

            }
            catch (Exception ex)
            {
                //  MessageBox.Show(""+ex);
            }
            con.Close();
        }
        }
        }
    

