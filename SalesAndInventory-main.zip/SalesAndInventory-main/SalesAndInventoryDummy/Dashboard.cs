﻿using FontAwesome.Sharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesAndInventoryDummy
{
    public partial class Dashboard : Form
    {
        private IconButton currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;
        public Dashboard()
        {
            InitializeComponent();
            random = new Random();
            custimizedesign();
        }

        private Color SelectThemeColor()
        {
            int index = random.Next(Themecolor.ColorList.Count);
            while (tempIndex == index)
            {
                index = random.Next(Themecolor.ColorList.Count);
            }
            tempIndex = index;
            string color = Themecolor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }

        private void ActivateButton(object btnSender)
        {
            if (btnSender != null)
            {
                if (currentButton != (IconButton)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (IconButton)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                    panelheader.BackColor = color;
                    //panelLogo.BackColor = Themecolor.ChangeColorBrightness(color, -0.3);
                    //Themecolor.PrimaryColor = color;
                    //Themecolor.SecondaryColor = Themecolor.ChangeColorBrightness(color, -0.3);
                    // btnCloseChildForm.Visible = true;
                }
            }
        }
        private void DisableButton()
        {
            foreach (Control previousBtn in panelhome.Controls)
            {
                if (previousBtn.GetType() == typeof(IconButton))
                {
                    previousBtn.BackColor = Color.FromArgb(51, 51, 76);
                    previousBtn.ForeColor = Color.Gainsboro;
                    previousBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                }
            }
        }

        private void openchildform(Form childform, object btnsender)
        {
            if (activeForm != null)
            {
                activeForm.Close();

            }
            ActivateButton(btnsender);
            activeForm = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;

            this.paneldesktopfull.Controls.Add(childform);
            this.paneldesktopfull.Tag = childform;
            childform.BringToFront();
            childform.Show();
            labelhome.Text = childform.Text;

        }

        private void custimizedesign()
        {
            panelsaledropdown.Visible = false;
            panelpurchasedropdown.Visible = false;
            panelcashandbankdropdown.Visible = false;
            panelbackuprestoredeopdown.Visible = false;
            panelutilitydropdown.Visible = false;
        }
        private void hidesubmenu()
        {
            if (panelsaledropdown.Visible == true)
                panelsaledropdown.Visible = false;
            if (panelpurchasedropdown.Visible == true)
                panelpurchasedropdown.Visible = false;
            if (panelcashandbankdropdown.Visible == true)
                panelcashandbankdropdown.Visible = false;
            if (panelbackuprestoredeopdown.Visible == true)
                panelbackuprestoredeopdown.Visible = false;
            if (panelutilitydropdown.Visible == true)
                panelutilitydropdown.Visible = false;

        }
        private void showsubmenu(Panel submenu)
        {
            if (submenu.Visible == false)
            {
                hidesubmenu();
                submenu.Visible = true;
            }
            else
                submenu.Visible = false;

        }

        private void iconBtnhome_Click(object sender, EventArgs e)
        {
            ActivateButton(sender);
            labelhome.Text = "Home";
            if (!paneldesktopfull.Controls.Contains(Homeusercontrol1.Instance))
            {
                paneldesktopfull.Controls.Add(Homeusercontrol1.Instance);
                Homeusercontrol1.Instance.Dock = DockStyle.Fill;
                Homeusercontrol1.Instance.BringToFront();

            }
            else
                Homeusercontrol1.Instance.BringToFront();
        }


        private void iconBtnitems_Click_1(object sender, EventArgs e)
        {
            ActivateButton(sender);
            // openchildform(new Items(), sender);
            labelhome.Text = "Items";

            if (!paneldesktopfull.Controls.Contains(Items.Instance1))
            {
                paneldesktopfull.Controls.Add(Items.Instance1);
                Items.Instance1.Dock = DockStyle.Fill;
                Items.Instance1.BringToFront();

            }
            else
                Items.Instance1.BringToFront();
        }

        private void iconBtnsale_Click(object sender, EventArgs e)
        {
            showsubmenu(panelsaledropdown);
        }

        private void iconBtnpurchase_Click(object sender, EventArgs e)
        {
            showsubmenu(panelsaledropdown);
        }

        private void iconBtncashandbank_Click(object sender, EventArgs e)
        {
            showsubmenu(panelsaledropdown);
        }

        private void iconBtnbackuporrestore_Click(object sender, EventArgs e)
        {
            showsubmenu(panelsaledropdown);
        }

        private void iconBtnutilities_Click(object sender, EventArgs e)
        {
            showsubmenu(panelsaledropdown);
        }
    }
}
