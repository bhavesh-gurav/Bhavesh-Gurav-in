﻿namespace SalesAndInventoryDummy
{
    partial class UserControlservices
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonaddfrtservice = new System.Windows.Forms.Button();
            this.labeladdser = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonaddfrtservice
            // 
            this.buttonaddfrtservice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonaddfrtservice.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonaddfrtservice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonaddfrtservice.ForeColor = System.Drawing.Color.White;
            this.buttonaddfrtservice.Location = new System.Drawing.Point(291, 273);
            this.buttonaddfrtservice.Name = "buttonaddfrtservice";
            this.buttonaddfrtservice.Size = new System.Drawing.Size(413, 40);
            this.buttonaddfrtservice.TabIndex = 0;
            this.buttonaddfrtservice.Text = "Add Your First Service";
            this.buttonaddfrtservice.UseVisualStyleBackColor = false;
            // 
            // labeladdser
            // 
            this.labeladdser.AutoSize = true;
            this.labeladdser.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeladdser.Location = new System.Drawing.Point(210, 237);
            this.labeladdser.Name = "labeladdser";
            this.labeladdser.Size = new System.Drawing.Size(601, 20);
            this.labeladdser.TabIndex = 1;
            this.labeladdser.Text = "Add services you provide to your customers and create Sale invoices for them fast" +
    "er.";
            // 
            // UserControlservices
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.labeladdser);
            this.Controls.Add(this.buttonaddfrtservice);
            this.Name = "UserControlservices";
            this.Size = new System.Drawing.Size(923, 465);
            this.Load += new System.EventHandler(this.UserControlservices_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonaddfrtservice;
        private System.Windows.Forms.Label labeladdser;
    }
}
