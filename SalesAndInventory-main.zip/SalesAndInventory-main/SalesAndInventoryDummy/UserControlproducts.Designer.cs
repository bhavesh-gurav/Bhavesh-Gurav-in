﻿namespace SalesAndInventoryDummy
{
    partial class UserControlproducts
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonaddyour = new System.Windows.Forms.Button();
            this.labeladdproducts = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonaddyour
            // 
            this.buttonaddyour.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.buttonaddyour.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonaddyour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonaddyour.ForeColor = System.Drawing.Color.White;
            this.buttonaddyour.Location = new System.Drawing.Point(291, 273);
            this.buttonaddyour.Name = "buttonaddyour";
            this.buttonaddyour.Size = new System.Drawing.Size(413, 40);
            this.buttonaddyour.TabIndex = 0;
            this.buttonaddyour.Text = "Add Your First Product";
            this.buttonaddyour.UseVisualStyleBackColor = false;
            // 
            // labeladdproducts
            // 
            this.labeladdproducts.AutoSize = true;
            this.labeladdproducts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeladdproducts.Location = new System.Drawing.Point(210, 237);
            this.labeladdproducts.Name = "labeladdproducts";
            this.labeladdproducts.Size = new System.Drawing.Size(549, 20);
            this.labeladdproducts.TabIndex = 1;
            this.labeladdproducts.Text = "Add Products/Items you sell or purchase to manage your full Stock Inventory.";
            // 
            // UserControlproducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.labeladdproducts);
            this.Controls.Add(this.buttonaddyour);
            this.Name = "UserControlproducts";
            this.Size = new System.Drawing.Size(923, 465);
            this.Load += new System.EventHandler(this.UserControlproducts_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonaddyour;
        private System.Windows.Forms.Label labeladdproducts;
    }
}
