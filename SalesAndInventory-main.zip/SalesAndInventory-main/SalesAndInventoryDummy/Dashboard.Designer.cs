﻿
namespace SalesAndInventoryDummy
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_sidebar = new System.Windows.Forms.Panel();
            this.panelhome = new System.Windows.Forms.Panel();
            this.iconBtnsharefeedback = new FontAwesome.Sharp.IconButton();
            this.iconBtnrequestdemo = new FontAwesome.Sharp.IconButton();
            this.iconBtntrialinfo = new FontAwesome.Sharp.IconButton();
            this.iconBtnreferandearn = new FontAwesome.Sharp.IconButton();
            this.iconBtnsetting = new FontAwesome.Sharp.IconButton();
            this.panelutilitydropdown = new System.Windows.Forms.Panel();
            this.btnclosefinyear = new System.Windows.Forms.Button();
            this.btnrefererralcode = new System.Windows.Forms.Button();
            this.btngeneratebarcode = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.iconBtnutilities = new FontAwesome.Sharp.IconButton();
            this.panelbackuprestoredeopdown = new System.Windows.Forms.Panel();
            this.btnrestorebackup = new System.Windows.Forms.Button();
            this.btnbackuptodrive = new System.Windows.Forms.Button();
            this.btnbackuptocomputer = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.iconBtnbackuporrestore = new FontAwesome.Sharp.IconButton();
            this.iconBtnsync = new FontAwesome.Sharp.IconButton();
            this.iconBtnreport = new FontAwesome.Sharp.IconButton();
            this.iconBtnmyonlinestore = new FontAwesome.Sharp.IconButton();
            this.panelcashandbankdropdown = new System.Windows.Forms.Panel();
            this.btnloanaccounts = new System.Windows.Forms.Button();
            this.btncheques = new System.Windows.Forms.Button();
            this.btncashinhand = new System.Windows.Forms.Button();
            this.btnbankaccount = new System.Windows.Forms.Button();
            this.iconBtncashandbank = new FontAwesome.Sharp.IconButton();
            this.iconBtnexpenses = new FontAwesome.Sharp.IconButton();
            this.panelpurchasedropdown = new System.Windows.Forms.Panel();
            this.btnpurchasereturn = new System.Windows.Forms.Button();
            this.btnpurchaseorder = new System.Windows.Forms.Button();
            this.btnpaymentout = new System.Windows.Forms.Button();
            this.btnpurchasebills = new System.Windows.Forms.Button();
            this.iconBtnpurchase = new FontAwesome.Sharp.IconButton();
            this.panelsaledropdown = new System.Windows.Forms.Panel();
            this.btnsalereturn = new System.Windows.Forms.Button();
            this.btndeliverychallan = new System.Windows.Forms.Button();
            this.btnsaleorder = new System.Windows.Forms.Button();
            this.btnpaymentin = new System.Windows.Forms.Button();
            this.btnestimateorcquotation = new System.Windows.Forms.Button();
            this.btnsaleinvoices = new System.Windows.Forms.Button();
            this.iconBtnsale = new FontAwesome.Sharp.IconButton();
            this.iconBtnitems = new FontAwesome.Sharp.IconButton();
            this.iconBtnparties = new FontAwesome.Sharp.IconButton();
            this.iconBtnhome = new FontAwesome.Sharp.IconButton();
            this.iconBtnprotuple = new FontAwesome.Sharp.IconButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelheader = new System.Windows.Forms.Panel();
            this.iconBtnaddsale = new FontAwesome.Sharp.IconButton();
            this.iconButtonaddmore = new FontAwesome.Sharp.IconButton();
            this.iconButtonaddpurchase = new FontAwesome.Sharp.IconButton();
            this.labelhome = new System.Windows.Forms.Label();
            this.paneldesktopfull = new System.Windows.Forms.Panel();
            this.panel_sidebar.SuspendLayout();
            this.panelhome.SuspendLayout();
            this.panelutilitydropdown.SuspendLayout();
            this.panelbackuprestoredeopdown.SuspendLayout();
            this.panelcashandbankdropdown.SuspendLayout();
            this.panelpurchasedropdown.SuspendLayout();
            this.panelsaledropdown.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelheader.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_sidebar
            // 
            this.panel_sidebar.AutoScroll = true;
            this.panel_sidebar.Controls.Add(this.panelhome);
            this.panel_sidebar.Controls.Add(this.iconBtnprotuple);
            this.panel_sidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_sidebar.Location = new System.Drawing.Point(0, 0);
            this.panel_sidebar.Name = "panel_sidebar";
            this.panel_sidebar.Size = new System.Drawing.Size(227, 681);
            this.panel_sidebar.TabIndex = 3;
            // 
            // panelhome
            // 
            this.panelhome.AutoScroll = true;
            this.panelhome.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelhome.Controls.Add(this.iconBtnsharefeedback);
            this.panelhome.Controls.Add(this.iconBtnrequestdemo);
            this.panelhome.Controls.Add(this.iconBtntrialinfo);
            this.panelhome.Controls.Add(this.iconBtnreferandearn);
            this.panelhome.Controls.Add(this.iconBtnsetting);
            this.panelhome.Controls.Add(this.panelutilitydropdown);
            this.panelhome.Controls.Add(this.iconBtnutilities);
            this.panelhome.Controls.Add(this.panelbackuprestoredeopdown);
            this.panelhome.Controls.Add(this.iconBtnbackuporrestore);
            this.panelhome.Controls.Add(this.iconBtnsync);
            this.panelhome.Controls.Add(this.iconBtnreport);
            this.panelhome.Controls.Add(this.iconBtnmyonlinestore);
            this.panelhome.Controls.Add(this.panelcashandbankdropdown);
            this.panelhome.Controls.Add(this.iconBtncashandbank);
            this.panelhome.Controls.Add(this.iconBtnexpenses);
            this.panelhome.Controls.Add(this.panelpurchasedropdown);
            this.panelhome.Controls.Add(this.iconBtnpurchase);
            this.panelhome.Controls.Add(this.panelsaledropdown);
            this.panelhome.Controls.Add(this.iconBtnsale);
            this.panelhome.Controls.Add(this.iconBtnitems);
            this.panelhome.Controls.Add(this.iconBtnparties);
            this.panelhome.Controls.Add(this.iconBtnhome);
            this.panelhome.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelhome.Location = new System.Drawing.Point(0, 62);
            this.panelhome.Name = "panelhome";
            this.panelhome.Size = new System.Drawing.Size(227, 619);
            this.panelhome.TabIndex = 1;
            // 
            // iconBtnsharefeedback
            // 
            this.iconBtnsharefeedback.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnsharefeedback.FlatAppearance.BorderSize = 0;
            this.iconBtnsharefeedback.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnsharefeedback.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnsharefeedback.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnsharefeedback.IconChar = FontAwesome.Sharp.IconChar.Star;
            this.iconBtnsharefeedback.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnsharefeedback.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnsharefeedback.Location = new System.Drawing.Point(0, 1387);
            this.iconBtnsharefeedback.Name = "iconBtnsharefeedback";
            this.iconBtnsharefeedback.Size = new System.Drawing.Size(210, 68);
            this.iconBtnsharefeedback.TabIndex = 21;
            this.iconBtnsharefeedback.Text = "Share Feedback";
            this.iconBtnsharefeedback.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnsharefeedback.UseVisualStyleBackColor = true;
            // 
            // iconBtnrequestdemo
            // 
            this.iconBtnrequestdemo.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnrequestdemo.FlatAppearance.BorderSize = 0;
            this.iconBtnrequestdemo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnrequestdemo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnrequestdemo.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnrequestdemo.IconChar = FontAwesome.Sharp.IconChar.Fish;
            this.iconBtnrequestdemo.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnrequestdemo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnrequestdemo.Location = new System.Drawing.Point(0, 1345);
            this.iconBtnrequestdemo.Name = "iconBtnrequestdemo";
            this.iconBtnrequestdemo.Size = new System.Drawing.Size(210, 42);
            this.iconBtnrequestdemo.TabIndex = 20;
            this.iconBtnrequestdemo.Text = "Request A Demo";
            this.iconBtnrequestdemo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnrequestdemo.UseVisualStyleBackColor = true;
            // 
            // iconBtntrialinfo
            // 
            this.iconBtntrialinfo.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtntrialinfo.FlatAppearance.BorderSize = 0;
            this.iconBtntrialinfo.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtntrialinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtntrialinfo.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtntrialinfo.IconChar = FontAwesome.Sharp.IconChar.Award;
            this.iconBtntrialinfo.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtntrialinfo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtntrialinfo.Location = new System.Drawing.Point(0, 1309);
            this.iconBtntrialinfo.Name = "iconBtntrialinfo";
            this.iconBtntrialinfo.Size = new System.Drawing.Size(210, 36);
            this.iconBtntrialinfo.TabIndex = 19;
            this.iconBtntrialinfo.Text = "Trial Info";
            this.iconBtntrialinfo.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtntrialinfo.UseVisualStyleBackColor = true;
            // 
            // iconBtnreferandearn
            // 
            this.iconBtnreferandearn.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnreferandearn.FlatAppearance.BorderSize = 0;
            this.iconBtnreferandearn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnreferandearn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnreferandearn.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnreferandearn.IconChar = FontAwesome.Sharp.IconChar.Gift;
            this.iconBtnreferandearn.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnreferandearn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnreferandearn.Location = new System.Drawing.Point(0, 1267);
            this.iconBtnreferandearn.Name = "iconBtnreferandearn";
            this.iconBtnreferandearn.Size = new System.Drawing.Size(210, 42);
            this.iconBtnreferandearn.TabIndex = 18;
            this.iconBtnreferandearn.Text = "Refer And Earn";
            this.iconBtnreferandearn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnreferandearn.UseVisualStyleBackColor = true;
            // 
            // iconBtnsetting
            // 
            this.iconBtnsetting.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnsetting.FlatAppearance.BorderSize = 0;
            this.iconBtnsetting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnsetting.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnsetting.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnsetting.IconChar = FontAwesome.Sharp.IconChar.Whmcs;
            this.iconBtnsetting.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnsetting.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnsetting.Location = new System.Drawing.Point(0, 1217);
            this.iconBtnsetting.Name = "iconBtnsetting";
            this.iconBtnsetting.Size = new System.Drawing.Size(210, 50);
            this.iconBtnsetting.TabIndex = 17;
            this.iconBtnsetting.Text = "Setting";
            this.iconBtnsetting.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnsetting.UseVisualStyleBackColor = true;
            // 
            // panelutilitydropdown
            // 
            this.panelutilitydropdown.Controls.Add(this.btnclosefinyear);
            this.panelutilitydropdown.Controls.Add(this.btnrefererralcode);
            this.panelutilitydropdown.Controls.Add(this.btngeneratebarcode);
            this.panelutilitydropdown.Controls.Add(this.button30);
            this.panelutilitydropdown.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelutilitydropdown.Location = new System.Drawing.Point(0, 1107);
            this.panelutilitydropdown.Name = "panelutilitydropdown";
            this.panelutilitydropdown.Size = new System.Drawing.Size(210, 110);
            this.panelutilitydropdown.TabIndex = 16;
            // 
            // btnclosefinyear
            // 
            this.btnclosefinyear.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnclosefinyear.FlatAppearance.BorderSize = 0;
            this.btnclosefinyear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnclosefinyear.Location = new System.Drawing.Point(0, 80);
            this.btnclosefinyear.Name = "btnclosefinyear";
            this.btnclosefinyear.Size = new System.Drawing.Size(210, 33);
            this.btnclosefinyear.TabIndex = 11;
            this.btnclosefinyear.Text = "Close Finanacial Year";
            this.btnclosefinyear.UseVisualStyleBackColor = true;
            // 
            // btnrefererralcode
            // 
            this.btnrefererralcode.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnrefererralcode.FlatAppearance.BorderSize = 0;
            this.btnrefererralcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrefererralcode.Location = new System.Drawing.Point(0, 47);
            this.btnrefererralcode.Name = "btnrefererralcode";
            this.btnrefererralcode.Size = new System.Drawing.Size(210, 33);
            this.btnrefererralcode.TabIndex = 10;
            this.btnrefererralcode.Text = "Referral Code";
            this.btnrefererralcode.UseVisualStyleBackColor = true;
            // 
            // btngeneratebarcode
            // 
            this.btngeneratebarcode.Dock = System.Windows.Forms.DockStyle.Top;
            this.btngeneratebarcode.FlatAppearance.BorderSize = 0;
            this.btngeneratebarcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btngeneratebarcode.Location = new System.Drawing.Point(0, 10);
            this.btngeneratebarcode.Name = "btngeneratebarcode";
            this.btngeneratebarcode.Size = new System.Drawing.Size(210, 37);
            this.btngeneratebarcode.TabIndex = 9;
            this.btngeneratebarcode.Text = "Generate Barcode";
            this.btngeneratebarcode.UseVisualStyleBackColor = true;
            // 
            // button30
            // 
            this.button30.Dock = System.Windows.Forms.DockStyle.Top;
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(0, 0);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(210, 10);
            this.button30.TabIndex = 8;
            this.button30.Text = "Auto Backup";
            this.button30.UseVisualStyleBackColor = true;
            // 
            // iconBtnutilities
            // 
            this.iconBtnutilities.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnutilities.FlatAppearance.BorderSize = 0;
            this.iconBtnutilities.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnutilities.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnutilities.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnutilities.IconChar = FontAwesome.Sharp.IconChar.Wrench;
            this.iconBtnutilities.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnutilities.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnutilities.Location = new System.Drawing.Point(0, 1065);
            this.iconBtnutilities.Name = "iconBtnutilities";
            this.iconBtnutilities.Size = new System.Drawing.Size(210, 42);
            this.iconBtnutilities.TabIndex = 15;
            this.iconBtnutilities.Text = "Utilities";
            this.iconBtnutilities.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnutilities.UseVisualStyleBackColor = true;
            this.iconBtnutilities.Click += new System.EventHandler(this.iconBtnutilities_Click);
            // 
            // panelbackuprestoredeopdown
            // 
            this.panelbackuprestoredeopdown.Controls.Add(this.btnrestorebackup);
            this.panelbackuprestoredeopdown.Controls.Add(this.btnbackuptodrive);
            this.panelbackuprestoredeopdown.Controls.Add(this.btnbackuptocomputer);
            this.panelbackuprestoredeopdown.Controls.Add(this.button26);
            this.panelbackuprestoredeopdown.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelbackuprestoredeopdown.Location = new System.Drawing.Point(0, 951);
            this.panelbackuprestoredeopdown.Name = "panelbackuprestoredeopdown";
            this.panelbackuprestoredeopdown.Size = new System.Drawing.Size(210, 114);
            this.panelbackuprestoredeopdown.TabIndex = 14;
            // 
            // btnrestorebackup
            // 
            this.btnrestorebackup.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnrestorebackup.FlatAppearance.BorderSize = 0;
            this.btnrestorebackup.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnrestorebackup.Location = new System.Drawing.Point(0, 80);
            this.btnrestorebackup.Name = "btnrestorebackup";
            this.btnrestorebackup.Size = new System.Drawing.Size(210, 34);
            this.btnrestorebackup.TabIndex = 11;
            this.btnrestorebackup.Text = "Restore Backup";
            this.btnrestorebackup.UseVisualStyleBackColor = true;
            // 
            // btnbackuptodrive
            // 
            this.btnbackuptodrive.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnbackuptodrive.FlatAppearance.BorderSize = 0;
            this.btnbackuptodrive.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbackuptodrive.Location = new System.Drawing.Point(0, 47);
            this.btnbackuptodrive.Name = "btnbackuptodrive";
            this.btnbackuptodrive.Size = new System.Drawing.Size(210, 33);
            this.btnbackuptodrive.TabIndex = 10;
            this.btnbackuptodrive.Text = "Backup to Drive";
            this.btnbackuptodrive.UseVisualStyleBackColor = true;
            // 
            // btnbackuptocomputer
            // 
            this.btnbackuptocomputer.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnbackuptocomputer.FlatAppearance.BorderSize = 0;
            this.btnbackuptocomputer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbackuptocomputer.Location = new System.Drawing.Point(0, 10);
            this.btnbackuptocomputer.Name = "btnbackuptocomputer";
            this.btnbackuptocomputer.Size = new System.Drawing.Size(210, 37);
            this.btnbackuptocomputer.TabIndex = 9;
            this.btnbackuptocomputer.Text = "Backup To Computer";
            this.btnbackuptocomputer.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Dock = System.Windows.Forms.DockStyle.Top;
            this.button26.FlatAppearance.BorderSize = 0;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(0, 0);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(210, 10);
            this.button26.TabIndex = 8;
            this.button26.Text = "Auto Backup";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // iconBtnbackuporrestore
            // 
            this.iconBtnbackuporrestore.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnbackuporrestore.FlatAppearance.BorderSize = 0;
            this.iconBtnbackuporrestore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnbackuporrestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnbackuporrestore.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnbackuporrestore.IconChar = FontAwesome.Sharp.IconChar.CloudMeatball;
            this.iconBtnbackuporrestore.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnbackuporrestore.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnbackuporrestore.Location = new System.Drawing.Point(0, 905);
            this.iconBtnbackuporrestore.Name = "iconBtnbackuporrestore";
            this.iconBtnbackuporrestore.Size = new System.Drawing.Size(210, 46);
            this.iconBtnbackuporrestore.TabIndex = 13;
            this.iconBtnbackuporrestore.Text = "Backup Or Restore";
            this.iconBtnbackuporrestore.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnbackuporrestore.UseVisualStyleBackColor = true;
            this.iconBtnbackuporrestore.Click += new System.EventHandler(this.iconBtnbackuporrestore_Click);
            // 
            // iconBtnsync
            // 
            this.iconBtnsync.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnsync.FlatAppearance.BorderSize = 0;
            this.iconBtnsync.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnsync.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnsync.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnsync.IconChar = FontAwesome.Sharp.IconChar.Sync;
            this.iconBtnsync.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnsync.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnsync.Location = new System.Drawing.Point(0, 863);
            this.iconBtnsync.Name = "iconBtnsync";
            this.iconBtnsync.Size = new System.Drawing.Size(210, 42);
            this.iconBtnsync.TabIndex = 12;
            this.iconBtnsync.Text = "Sync";
            this.iconBtnsync.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnsync.UseVisualStyleBackColor = true;
            // 
            // iconBtnreport
            // 
            this.iconBtnreport.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnreport.FlatAppearance.BorderSize = 0;
            this.iconBtnreport.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnreport.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnreport.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnreport.IconChar = FontAwesome.Sharp.IconChar.Signal;
            this.iconBtnreport.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnreport.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnreport.Location = new System.Drawing.Point(0, 821);
            this.iconBtnreport.Name = "iconBtnreport";
            this.iconBtnreport.Size = new System.Drawing.Size(210, 42);
            this.iconBtnreport.TabIndex = 11;
            this.iconBtnreport.Text = "Report";
            this.iconBtnreport.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnreport.UseVisualStyleBackColor = true;
            // 
            // iconBtnmyonlinestore
            // 
            this.iconBtnmyonlinestore.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnmyonlinestore.FlatAppearance.BorderSize = 0;
            this.iconBtnmyonlinestore.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnmyonlinestore.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnmyonlinestore.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnmyonlinestore.IconChar = FontAwesome.Sharp.IconChar.GgCircle;
            this.iconBtnmyonlinestore.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnmyonlinestore.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnmyonlinestore.Location = new System.Drawing.Point(0, 779);
            this.iconBtnmyonlinestore.Name = "iconBtnmyonlinestore";
            this.iconBtnmyonlinestore.Size = new System.Drawing.Size(210, 42);
            this.iconBtnmyonlinestore.TabIndex = 10;
            this.iconBtnmyonlinestore.Text = "My Online Store";
            this.iconBtnmyonlinestore.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnmyonlinestore.UseVisualStyleBackColor = true;
            // 
            // panelcashandbankdropdown
            // 
            this.panelcashandbankdropdown.Controls.Add(this.btnloanaccounts);
            this.panelcashandbankdropdown.Controls.Add(this.btncheques);
            this.panelcashandbankdropdown.Controls.Add(this.btncashinhand);
            this.panelcashandbankdropdown.Controls.Add(this.btnbankaccount);
            this.panelcashandbankdropdown.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelcashandbankdropdown.Location = new System.Drawing.Point(0, 643);
            this.panelcashandbankdropdown.Name = "panelcashandbankdropdown";
            this.panelcashandbankdropdown.Size = new System.Drawing.Size(210, 136);
            this.panelcashandbankdropdown.TabIndex = 9;
            // 
            // btnloanaccounts
            // 
            this.btnloanaccounts.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnloanaccounts.FlatAppearance.BorderSize = 0;
            this.btnloanaccounts.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnloanaccounts.Location = new System.Drawing.Point(0, 99);
            this.btnloanaccounts.Name = "btnloanaccounts";
            this.btnloanaccounts.Size = new System.Drawing.Size(210, 33);
            this.btnloanaccounts.TabIndex = 11;
            this.btnloanaccounts.Text = "Loan Accounts";
            this.btnloanaccounts.UseVisualStyleBackColor = true;
            // 
            // btncheques
            // 
            this.btncheques.Dock = System.Windows.Forms.DockStyle.Top;
            this.btncheques.FlatAppearance.BorderSize = 0;
            this.btncheques.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncheques.Location = new System.Drawing.Point(0, 66);
            this.btncheques.Name = "btncheques";
            this.btncheques.Size = new System.Drawing.Size(210, 33);
            this.btncheques.TabIndex = 10;
            this.btncheques.Text = "Cheques";
            this.btncheques.UseVisualStyleBackColor = true;
            // 
            // btncashinhand
            // 
            this.btncashinhand.Dock = System.Windows.Forms.DockStyle.Top;
            this.btncashinhand.FlatAppearance.BorderSize = 0;
            this.btncashinhand.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btncashinhand.Location = new System.Drawing.Point(0, 33);
            this.btncashinhand.Name = "btncashinhand";
            this.btncashinhand.Size = new System.Drawing.Size(210, 33);
            this.btncashinhand.TabIndex = 9;
            this.btncashinhand.Text = "Cash In Hand";
            this.btncashinhand.UseVisualStyleBackColor = true;
            // 
            // btnbankaccount
            // 
            this.btnbankaccount.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnbankaccount.FlatAppearance.BorderSize = 0;
            this.btnbankaccount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnbankaccount.Location = new System.Drawing.Point(0, 0);
            this.btnbankaccount.Name = "btnbankaccount";
            this.btnbankaccount.Size = new System.Drawing.Size(210, 33);
            this.btnbankaccount.TabIndex = 8;
            this.btnbankaccount.Text = "Bank Accounts";
            this.btnbankaccount.UseVisualStyleBackColor = true;
            // 
            // iconBtncashandbank
            // 
            this.iconBtncashandbank.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtncashandbank.FlatAppearance.BorderSize = 0;
            this.iconBtncashandbank.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtncashandbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtncashandbank.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtncashandbank.IconChar = FontAwesome.Sharp.IconChar.CartPlus;
            this.iconBtncashandbank.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtncashandbank.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtncashandbank.Location = new System.Drawing.Point(0, 601);
            this.iconBtncashandbank.Name = "iconBtncashandbank";
            this.iconBtncashandbank.Size = new System.Drawing.Size(210, 42);
            this.iconBtncashandbank.TabIndex = 8;
            this.iconBtncashandbank.Text = "Cash and Bank";
            this.iconBtncashandbank.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtncashandbank.UseVisualStyleBackColor = true;
            this.iconBtncashandbank.Click += new System.EventHandler(this.iconBtncashandbank_Click);
            // 
            // iconBtnexpenses
            // 
            this.iconBtnexpenses.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnexpenses.FlatAppearance.BorderSize = 0;
            this.iconBtnexpenses.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnexpenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnexpenses.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnexpenses.IconChar = FontAwesome.Sharp.IconChar.Ethernet;
            this.iconBtnexpenses.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnexpenses.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnexpenses.Location = new System.Drawing.Point(0, 559);
            this.iconBtnexpenses.Name = "iconBtnexpenses";
            this.iconBtnexpenses.Size = new System.Drawing.Size(210, 42);
            this.iconBtnexpenses.TabIndex = 7;
            this.iconBtnexpenses.Text = "Expenses";
            this.iconBtnexpenses.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnexpenses.UseVisualStyleBackColor = true;
            // 
            // panelpurchasedropdown
            // 
            this.panelpurchasedropdown.Controls.Add(this.btnpurchasereturn);
            this.panelpurchasedropdown.Controls.Add(this.btnpurchaseorder);
            this.panelpurchasedropdown.Controls.Add(this.btnpaymentout);
            this.panelpurchasedropdown.Controls.Add(this.btnpurchasebills);
            this.panelpurchasedropdown.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelpurchasedropdown.Location = new System.Drawing.Point(0, 421);
            this.panelpurchasedropdown.Name = "panelpurchasedropdown";
            this.panelpurchasedropdown.Size = new System.Drawing.Size(210, 138);
            this.panelpurchasedropdown.TabIndex = 6;
            // 
            // btnpurchasereturn
            // 
            this.btnpurchasereturn.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnpurchasereturn.FlatAppearance.BorderSize = 0;
            this.btnpurchasereturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpurchasereturn.Location = new System.Drawing.Point(0, 99);
            this.btnpurchasereturn.Name = "btnpurchasereturn";
            this.btnpurchasereturn.Size = new System.Drawing.Size(210, 33);
            this.btnpurchasereturn.TabIndex = 11;
            this.btnpurchasereturn.Text = "Purchase Return/Dr.Note";
            this.btnpurchasereturn.UseVisualStyleBackColor = true;
            // 
            // btnpurchaseorder
            // 
            this.btnpurchaseorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnpurchaseorder.FlatAppearance.BorderSize = 0;
            this.btnpurchaseorder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpurchaseorder.Location = new System.Drawing.Point(0, 66);
            this.btnpurchaseorder.Name = "btnpurchaseorder";
            this.btnpurchaseorder.Size = new System.Drawing.Size(210, 33);
            this.btnpurchaseorder.TabIndex = 10;
            this.btnpurchaseorder.Text = "Purchase Order";
            this.btnpurchaseorder.UseVisualStyleBackColor = true;
            // 
            // btnpaymentout
            // 
            this.btnpaymentout.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnpaymentout.FlatAppearance.BorderSize = 0;
            this.btnpaymentout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpaymentout.Location = new System.Drawing.Point(0, 33);
            this.btnpaymentout.Name = "btnpaymentout";
            this.btnpaymentout.Size = new System.Drawing.Size(210, 33);
            this.btnpaymentout.TabIndex = 9;
            this.btnpaymentout.Text = "Payment Out";
            this.btnpaymentout.UseVisualStyleBackColor = true;
            // 
            // btnpurchasebills
            // 
            this.btnpurchasebills.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnpurchasebills.FlatAppearance.BorderSize = 0;
            this.btnpurchasebills.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpurchasebills.Location = new System.Drawing.Point(0, 0);
            this.btnpurchasebills.Name = "btnpurchasebills";
            this.btnpurchasebills.Size = new System.Drawing.Size(210, 33);
            this.btnpurchasebills.TabIndex = 8;
            this.btnpurchasebills.Text = "Purchase Bills";
            this.btnpurchasebills.UseVisualStyleBackColor = true;
            // 
            // iconBtnpurchase
            // 
            this.iconBtnpurchase.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnpurchase.FlatAppearance.BorderSize = 0;
            this.iconBtnpurchase.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnpurchase.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnpurchase.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnpurchase.IconChar = FontAwesome.Sharp.IconChar.CartPlus;
            this.iconBtnpurchase.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnpurchase.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnpurchase.Location = new System.Drawing.Point(0, 379);
            this.iconBtnpurchase.Name = "iconBtnpurchase";
            this.iconBtnpurchase.Size = new System.Drawing.Size(210, 42);
            this.iconBtnpurchase.TabIndex = 5;
            this.iconBtnpurchase.Text = "Purchase";
            this.iconBtnpurchase.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnpurchase.UseVisualStyleBackColor = true;
            this.iconBtnpurchase.Click += new System.EventHandler(this.iconBtnpurchase_Click);
            // 
            // panelsaledropdown
            // 
            this.panelsaledropdown.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panelsaledropdown.Controls.Add(this.btnsalereturn);
            this.panelsaledropdown.Controls.Add(this.btndeliverychallan);
            this.panelsaledropdown.Controls.Add(this.btnsaleorder);
            this.panelsaledropdown.Controls.Add(this.btnpaymentin);
            this.panelsaledropdown.Controls.Add(this.btnestimateorcquotation);
            this.panelsaledropdown.Controls.Add(this.btnsaleinvoices);
            this.panelsaledropdown.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelsaledropdown.Location = new System.Drawing.Point(0, 178);
            this.panelsaledropdown.Name = "panelsaledropdown";
            this.panelsaledropdown.Size = new System.Drawing.Size(210, 201);
            this.panelsaledropdown.TabIndex = 4;
            // 
            // btnsalereturn
            // 
            this.btnsalereturn.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnsalereturn.FlatAppearance.BorderSize = 0;
            this.btnsalereturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsalereturn.Location = new System.Drawing.Point(0, 165);
            this.btnsalereturn.Name = "btnsalereturn";
            this.btnsalereturn.Size = new System.Drawing.Size(210, 33);
            this.btnsalereturn.TabIndex = 13;
            this.btnsalereturn.Text = "Sale Return/Cr.Note";
            this.btnsalereturn.UseVisualStyleBackColor = true;
            // 
            // btndeliverychallan
            // 
            this.btndeliverychallan.Dock = System.Windows.Forms.DockStyle.Top;
            this.btndeliverychallan.FlatAppearance.BorderSize = 0;
            this.btndeliverychallan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndeliverychallan.Location = new System.Drawing.Point(0, 132);
            this.btndeliverychallan.Name = "btndeliverychallan";
            this.btndeliverychallan.Size = new System.Drawing.Size(210, 33);
            this.btndeliverychallan.TabIndex = 12;
            this.btndeliverychallan.Text = "Delivery Challan";
            this.btndeliverychallan.UseVisualStyleBackColor = true;
            // 
            // btnsaleorder
            // 
            this.btnsaleorder.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnsaleorder.FlatAppearance.BorderSize = 0;
            this.btnsaleorder.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsaleorder.Location = new System.Drawing.Point(0, 99);
            this.btnsaleorder.Name = "btnsaleorder";
            this.btnsaleorder.Size = new System.Drawing.Size(210, 33);
            this.btnsaleorder.TabIndex = 11;
            this.btnsaleorder.Text = "Sale Order";
            this.btnsaleorder.UseVisualStyleBackColor = true;
            // 
            // btnpaymentin
            // 
            this.btnpaymentin.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnpaymentin.FlatAppearance.BorderSize = 0;
            this.btnpaymentin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnpaymentin.Location = new System.Drawing.Point(0, 66);
            this.btnpaymentin.Name = "btnpaymentin";
            this.btnpaymentin.Size = new System.Drawing.Size(210, 33);
            this.btnpaymentin.TabIndex = 10;
            this.btnpaymentin.Text = "Payment In";
            this.btnpaymentin.UseVisualStyleBackColor = true;
            // 
            // btnestimateorcquotation
            // 
            this.btnestimateorcquotation.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnestimateorcquotation.FlatAppearance.BorderSize = 0;
            this.btnestimateorcquotation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnestimateorcquotation.Location = new System.Drawing.Point(0, 33);
            this.btnestimateorcquotation.Name = "btnestimateorcquotation";
            this.btnestimateorcquotation.Size = new System.Drawing.Size(210, 33);
            this.btnestimateorcquotation.TabIndex = 9;
            this.btnestimateorcquotation.Text = "Estimate/Quotation";
            this.btnestimateorcquotation.UseVisualStyleBackColor = true;
            // 
            // btnsaleinvoices
            // 
            this.btnsaleinvoices.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnsaleinvoices.FlatAppearance.BorderSize = 0;
            this.btnsaleinvoices.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnsaleinvoices.Location = new System.Drawing.Point(0, 0);
            this.btnsaleinvoices.Name = "btnsaleinvoices";
            this.btnsaleinvoices.Size = new System.Drawing.Size(210, 33);
            this.btnsaleinvoices.TabIndex = 8;
            this.btnsaleinvoices.Text = "Sale Invoices";
            this.btnsaleinvoices.UseVisualStyleBackColor = true;
            // 
            // iconBtnsale
            // 
            this.iconBtnsale.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnsale.FlatAppearance.BorderSize = 0;
            this.iconBtnsale.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnsale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnsale.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnsale.IconChar = FontAwesome.Sharp.IconChar.Anchor;
            this.iconBtnsale.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnsale.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnsale.Location = new System.Drawing.Point(0, 136);
            this.iconBtnsale.Name = "iconBtnsale";
            this.iconBtnsale.Size = new System.Drawing.Size(210, 42);
            this.iconBtnsale.TabIndex = 3;
            this.iconBtnsale.Text = "Sale";
            this.iconBtnsale.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnsale.UseVisualStyleBackColor = true;
            this.iconBtnsale.Click += new System.EventHandler(this.iconBtnsale_Click);
            // 
            // iconBtnitems
            // 
            this.iconBtnitems.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnitems.FlatAppearance.BorderSize = 0;
            this.iconBtnitems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnitems.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnitems.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnitems.IconChar = FontAwesome.Sharp.IconChar.Atlassian;
            this.iconBtnitems.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnitems.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnitems.Location = new System.Drawing.Point(0, 86);
            this.iconBtnitems.Name = "iconBtnitems";
            this.iconBtnitems.Size = new System.Drawing.Size(210, 50);
            this.iconBtnitems.TabIndex = 2;
            this.iconBtnitems.Text = "Items";
            this.iconBtnitems.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnitems.UseVisualStyleBackColor = true;
            this.iconBtnitems.Click += new System.EventHandler(this.iconBtnitems_Click_1);
            // 
            // iconBtnparties
            // 
            this.iconBtnparties.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnparties.FlatAppearance.BorderSize = 0;
            this.iconBtnparties.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnparties.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnparties.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnparties.IconChar = FontAwesome.Sharp.IconChar.UserFriends;
            this.iconBtnparties.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnparties.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnparties.Location = new System.Drawing.Point(0, 42);
            this.iconBtnparties.Name = "iconBtnparties";
            this.iconBtnparties.Size = new System.Drawing.Size(210, 44);
            this.iconBtnparties.TabIndex = 1;
            this.iconBtnparties.Text = "Parties";
            this.iconBtnparties.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnparties.UseVisualStyleBackColor = true;
            // 
            // iconBtnhome
            // 
            this.iconBtnhome.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.iconBtnhome.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnhome.FlatAppearance.BorderSize = 0;
            this.iconBtnhome.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnhome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnhome.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnhome.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.iconBtnhome.IconColor = System.Drawing.SystemColors.ControlLight;
            this.iconBtnhome.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnhome.Location = new System.Drawing.Point(0, 0);
            this.iconBtnhome.Name = "iconBtnhome";
            this.iconBtnhome.Size = new System.Drawing.Size(210, 42);
            this.iconBtnhome.TabIndex = 0;
            this.iconBtnhome.Text = "Home";
            this.iconBtnhome.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnhome.UseVisualStyleBackColor = false;
            this.iconBtnhome.Click += new System.EventHandler(this.iconBtnhome_Click);
            // 
            // iconBtnprotuple
            // 
            this.iconBtnprotuple.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.iconBtnprotuple.Dock = System.Windows.Forms.DockStyle.Top;
            this.iconBtnprotuple.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnprotuple.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.iconBtnprotuple.IconChar = FontAwesome.Sharp.IconChar.None;
            this.iconBtnprotuple.IconColor = System.Drawing.Color.Black;
            this.iconBtnprotuple.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnprotuple.Location = new System.Drawing.Point(0, 0);
            this.iconBtnprotuple.Name = "iconBtnprotuple";
            this.iconBtnprotuple.Size = new System.Drawing.Size(227, 62);
            this.iconBtnprotuple.TabIndex = 0;
            this.iconBtnprotuple.Text = "Pro-Tuple >";
            this.iconBtnprotuple.UseVisualStyleBackColor = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.paneldesktopfull);
            this.panel1.Controls.Add(this.panelheader);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(227, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1037, 681);
            this.panel1.TabIndex = 4;
            // 
            // panelheader
            // 
            this.panelheader.BackColor = System.Drawing.Color.DarkCyan;
            this.panelheader.Controls.Add(this.iconBtnaddsale);
            this.panelheader.Controls.Add(this.iconButtonaddmore);
            this.panelheader.Controls.Add(this.iconButtonaddpurchase);
            this.panelheader.Controls.Add(this.labelhome);
            this.panelheader.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelheader.Location = new System.Drawing.Point(0, 0);
            this.panelheader.Name = "panelheader";
            this.panelheader.Size = new System.Drawing.Size(1037, 62);
            this.panelheader.TabIndex = 3;
            // 
            // iconBtnaddsale
            // 
            this.iconBtnaddsale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconBtnaddsale.BackColor = System.Drawing.Color.Red;
            this.iconBtnaddsale.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnaddsale.ForeColor = System.Drawing.Color.White;
            this.iconBtnaddsale.IconChar = FontAwesome.Sharp.IconChar.Xbox;
            this.iconBtnaddsale.IconColor = System.Drawing.Color.White;
            this.iconBtnaddsale.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnaddsale.IconSize = 40;
            this.iconBtnaddsale.Location = new System.Drawing.Point(595, 12);
            this.iconBtnaddsale.Name = "iconBtnaddsale";
            this.iconBtnaddsale.Size = new System.Drawing.Size(127, 42);
            this.iconBtnaddsale.TabIndex = 0;
            this.iconBtnaddsale.Text = "Add Sale";
            this.iconBtnaddsale.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnaddsale.UseVisualStyleBackColor = false;
            // 
            // iconButtonaddmore
            // 
            this.iconButtonaddmore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconButtonaddmore.BackColor = System.Drawing.Color.White;
            this.iconButtonaddmore.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButtonaddmore.ForeColor = System.Drawing.Color.Navy;
            this.iconButtonaddmore.IconChar = FontAwesome.Sharp.IconChar.Xbox;
            this.iconButtonaddmore.IconColor = System.Drawing.Color.Navy;
            this.iconButtonaddmore.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButtonaddmore.IconSize = 40;
            this.iconButtonaddmore.Location = new System.Drawing.Point(896, 11);
            this.iconButtonaddmore.Name = "iconButtonaddmore";
            this.iconButtonaddmore.Size = new System.Drawing.Size(129, 42);
            this.iconButtonaddmore.TabIndex = 2;
            this.iconButtonaddmore.Text = "Add More";
            this.iconButtonaddmore.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButtonaddmore.UseVisualStyleBackColor = false;
            // 
            // iconButtonaddpurchase
            // 
            this.iconButtonaddpurchase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.iconButtonaddpurchase.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.iconButtonaddpurchase.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconButtonaddpurchase.ForeColor = System.Drawing.Color.White;
            this.iconButtonaddpurchase.IconChar = FontAwesome.Sharp.IconChar.Xbox;
            this.iconButtonaddpurchase.IconColor = System.Drawing.Color.White;
            this.iconButtonaddpurchase.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconButtonaddpurchase.IconSize = 40;
            this.iconButtonaddpurchase.Location = new System.Drawing.Point(731, 12);
            this.iconButtonaddpurchase.Name = "iconButtonaddpurchase";
            this.iconButtonaddpurchase.Size = new System.Drawing.Size(159, 42);
            this.iconButtonaddpurchase.TabIndex = 1;
            this.iconButtonaddpurchase.Text = "Add Purchase";
            this.iconButtonaddpurchase.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconButtonaddpurchase.UseVisualStyleBackColor = false;
            // 
            // labelhome
            // 
            this.labelhome.AutoSize = true;
            this.labelhome.Font = new System.Drawing.Font("Modern No. 20", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelhome.Location = new System.Drawing.Point(9, 21);
            this.labelhome.Name = "labelhome";
            this.labelhome.Size = new System.Drawing.Size(60, 21);
            this.labelhome.TabIndex = 0;
            this.labelhome.Text = "Home";
            // 
            // paneldesktopfull
            // 
            this.paneldesktopfull.Dock = System.Windows.Forms.DockStyle.Fill;
            this.paneldesktopfull.Location = new System.Drawing.Point(0, 62);
            this.paneldesktopfull.Name = "paneldesktopfull";
            this.paneldesktopfull.Size = new System.Drawing.Size(1037, 619);
            this.paneldesktopfull.TabIndex = 4;
            // 
            // Dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel_sidebar);
            this.MinimumSize = new System.Drawing.Size(1280, 720);
            this.Name = "Dashboard";
            this.Text = "Dashboard";
            this.panel_sidebar.ResumeLayout(false);
            this.panelhome.ResumeLayout(false);
            this.panelutilitydropdown.ResumeLayout(false);
            this.panelbackuprestoredeopdown.ResumeLayout(false);
            this.panelcashandbankdropdown.ResumeLayout(false);
            this.panelpurchasedropdown.ResumeLayout(false);
            this.panelsaledropdown.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panelheader.ResumeLayout(false);
            this.panelheader.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_sidebar;
        private System.Windows.Forms.Panel panelhome;
        private FontAwesome.Sharp.IconButton iconBtnsharefeedback;
        private FontAwesome.Sharp.IconButton iconBtnrequestdemo;
        private FontAwesome.Sharp.IconButton iconBtntrialinfo;
        private FontAwesome.Sharp.IconButton iconBtnreferandearn;
        private FontAwesome.Sharp.IconButton iconBtnsetting;
        private System.Windows.Forms.Panel panelutilitydropdown;
        private System.Windows.Forms.Button btnclosefinyear;
        private System.Windows.Forms.Button btnrefererralcode;
        private System.Windows.Forms.Button btngeneratebarcode;
        private System.Windows.Forms.Button button30;
        private FontAwesome.Sharp.IconButton iconBtnutilities;
        private System.Windows.Forms.Panel panelbackuprestoredeopdown;
        private System.Windows.Forms.Button btnrestorebackup;
        private System.Windows.Forms.Button btnbackuptodrive;
        private System.Windows.Forms.Button btnbackuptocomputer;
        private System.Windows.Forms.Button button26;
        private FontAwesome.Sharp.IconButton iconBtnbackuporrestore;
        private FontAwesome.Sharp.IconButton iconBtnsync;
        private FontAwesome.Sharp.IconButton iconBtnreport;
        private FontAwesome.Sharp.IconButton iconBtnmyonlinestore;
        private System.Windows.Forms.Panel panelcashandbankdropdown;
        private System.Windows.Forms.Button btnloanaccounts;
        private System.Windows.Forms.Button btncheques;
        private System.Windows.Forms.Button btncashinhand;
        private System.Windows.Forms.Button btnbankaccount;
        private FontAwesome.Sharp.IconButton iconBtncashandbank;
        private FontAwesome.Sharp.IconButton iconBtnexpenses;
        private System.Windows.Forms.Panel panelpurchasedropdown;
        private System.Windows.Forms.Button btnpurchasereturn;
        private System.Windows.Forms.Button btnpurchaseorder;
        private System.Windows.Forms.Button btnpaymentout;
        private System.Windows.Forms.Button btnpurchasebills;
        private FontAwesome.Sharp.IconButton iconBtnpurchase;
        private System.Windows.Forms.Panel panelsaledropdown;
        private System.Windows.Forms.Button btnsalereturn;
        private System.Windows.Forms.Button btndeliverychallan;
        private System.Windows.Forms.Button btnsaleorder;
        private System.Windows.Forms.Button btnpaymentin;
        private System.Windows.Forms.Button btnestimateorcquotation;
        private System.Windows.Forms.Button btnsaleinvoices;
        private FontAwesome.Sharp.IconButton iconBtnsale;
        private FontAwesome.Sharp.IconButton iconBtnitems;
        private FontAwesome.Sharp.IconButton iconBtnparties;
        private FontAwesome.Sharp.IconButton iconBtnhome;
        private FontAwesome.Sharp.IconButton iconBtnprotuple;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelheader;
        private FontAwesome.Sharp.IconButton iconBtnaddsale;
        private FontAwesome.Sharp.IconButton iconButtonaddmore;
        private FontAwesome.Sharp.IconButton iconButtonaddpurchase;
        private System.Windows.Forms.Label labelhome;
        public System.Windows.Forms.Panel paneldesktopfull;
    }
}