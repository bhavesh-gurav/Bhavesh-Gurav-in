﻿namespace SalesAndInventoryDummy
{
    partial class serviceusercontrol
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.paneladdservice = new System.Windows.Forms.Panel();
            this.iconBtnaddservices = new FontAwesome.Sharp.IconButton();
            this.iconBtndownarrow = new FontAwesome.Sharp.IconButton();
            this.iconpicturesearch = new FontAwesome.Sharp.IconPictureBox();
            this.iconBtnitem = new FontAwesome.Sharp.IconButton();
            this.panelsearch = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.iconBtnitemsname = new FontAwesome.Sharp.IconButton();
            this.labelsalepriceamounts = new System.Windows.Forms.Label();
            this.labelsalesprice = new System.Windows.Forms.Label();
            this.paneltranfill = new System.Windows.Forms.Panel();
            this.paneltransaction = new System.Windows.Forms.Panel();
            this.labeltransactions = new System.Windows.Forms.Label();
            this.iconPicboxsearch = new FontAwesome.Sharp.IconPictureBox();
            this.textBoxsearches = new System.Windows.Forms.TextBox();
            this.paneltypes = new System.Windows.Forms.Panel();
            this.iconBtntype = new FontAwesome.Sharp.IconButton();
            this.iconBtnname = new FontAwesome.Sharp.IconButton();
            this.iconBtndate = new FontAwesome.Sharp.IconButton();
            this.iconBtnqty = new FontAwesome.Sharp.IconButton();
            this.iconBtnprice = new FontAwesome.Sharp.IconButton();
            this.iconBtnstatus = new FontAwesome.Sharp.IconButton();
            this.paneladdservice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconpicturesearch)).BeginInit();
            this.panelsearch.SuspendLayout();
            this.panel2.SuspendLayout();
            this.paneltranfill.SuspendLayout();
            this.paneltransaction.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPicboxsearch)).BeginInit();
            this.paneltypes.SuspendLayout();
            this.SuspendLayout();
            // 
            // paneladdservice
            // 
            this.paneladdservice.BackColor = System.Drawing.Color.White;
            this.paneladdservice.Controls.Add(this.panelsearch);
            this.paneladdservice.Dock = System.Windows.Forms.DockStyle.Left;
            this.paneladdservice.Location = new System.Drawing.Point(0, 0);
            this.paneladdservice.Name = "paneladdservice";
            this.paneladdservice.Size = new System.Drawing.Size(243, 586);
            this.paneladdservice.TabIndex = 0;
            // 
            // iconBtnaddservices
            // 
            this.iconBtnaddservices.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.iconBtnaddservices.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconBtnaddservices.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnaddservices.ForeColor = System.Drawing.Color.White;
            this.iconBtnaddservices.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.iconBtnaddservices.IconColor = System.Drawing.Color.White;
            this.iconBtnaddservices.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnaddservices.IconSize = 30;
            this.iconBtnaddservices.Location = new System.Drawing.Point(84, 19);
            this.iconBtnaddservices.Name = "iconBtnaddservices";
            this.iconBtnaddservices.Size = new System.Drawing.Size(121, 32);
            this.iconBtnaddservices.TabIndex = 0;
            this.iconBtnaddservices.Text = "Add Service";
            this.iconBtnaddservices.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnaddservices.UseVisualStyleBackColor = false;
            // 
            // iconBtndownarrow
            // 
            this.iconBtndownarrow.BackColor = System.Drawing.Color.Goldenrod;
            this.iconBtndownarrow.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtndownarrow.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.iconBtndownarrow.IconChar = FontAwesome.Sharp.IconChar.AngleDown;
            this.iconBtndownarrow.IconColor = System.Drawing.Color.White;
            this.iconBtndownarrow.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtndownarrow.IconSize = 30;
            this.iconBtndownarrow.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.iconBtndownarrow.Location = new System.Drawing.Point(205, 19);
            this.iconBtndownarrow.Name = "iconBtndownarrow";
            this.iconBtndownarrow.Size = new System.Drawing.Size(31, 32);
            this.iconBtndownarrow.TabIndex = 3;
            this.iconBtndownarrow.UseVisualStyleBackColor = false;
            // 
            // iconpicturesearch
            // 
            this.iconpicturesearch.BackColor = System.Drawing.Color.Silver;
            this.iconpicturesearch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconpicturesearch.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconpicturesearch.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconpicturesearch.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconpicturesearch.Location = new System.Drawing.Point(19, 19);
            this.iconpicturesearch.Name = "iconpicturesearch";
            this.iconpicturesearch.Size = new System.Drawing.Size(32, 32);
            this.iconpicturesearch.TabIndex = 4;
            this.iconpicturesearch.TabStop = false;
            // 
            // iconBtnitem
            // 
            this.iconBtnitem.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnitem.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.iconBtnitem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnitem.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnitem.IconChar = FontAwesome.Sharp.IconChar.ArrowDown;
            this.iconBtnitem.IconColor = System.Drawing.Color.DarkRed;
            this.iconBtnitem.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnitem.IconSize = 30;
            this.iconBtnitem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnitem.Location = new System.Drawing.Point(0, 93);
            this.iconBtnitem.Name = "iconBtnitem";
            this.iconBtnitem.Size = new System.Drawing.Size(243, 36);
            this.iconBtnitem.TabIndex = 5;
            this.iconBtnitem.Text = "ITEM";
            this.iconBtnitem.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnitem.UseVisualStyleBackColor = true;
            // 
            // panelsearch
            // 
            this.panelsearch.Controls.Add(this.iconBtnitem);
            this.panelsearch.Controls.Add(this.iconpicturesearch);
            this.panelsearch.Controls.Add(this.iconBtnaddservices);
            this.panelsearch.Controls.Add(this.iconBtndownarrow);
            this.panelsearch.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelsearch.Location = new System.Drawing.Point(0, 0);
            this.panelsearch.Name = "panelsearch";
            this.panelsearch.Size = new System.Drawing.Size(243, 129);
            this.panelsearch.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.labelsalepriceamounts);
            this.panel2.Controls.Add(this.labelsalesprice);
            this.panel2.Controls.Add(this.iconBtnitemsname);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(243, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(736, 108);
            this.panel2.TabIndex = 1;
            // 
            // iconBtnitemsname
            // 
            this.iconBtnitemsname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnitemsname.Flip = FontAwesome.Sharp.FlipOrientation.Horizontal;
            this.iconBtnitemsname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnitemsname.IconChar = FontAwesome.Sharp.IconChar.Reply;
            this.iconBtnitemsname.IconColor = System.Drawing.Color.Black;
            this.iconBtnitemsname.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnitemsname.IconSize = 30;
            this.iconBtnitemsname.Location = new System.Drawing.Point(7, 8);
            this.iconBtnitemsname.Name = "iconBtnitemsname";
            this.iconBtnitemsname.Size = new System.Drawing.Size(106, 32);
            this.iconBtnitemsname.TabIndex = 1;
            this.iconBtnitemsname.Text = "ItemName";
            this.iconBtnitemsname.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnitemsname.UseVisualStyleBackColor = true;
            // 
            // labelsalepriceamounts
            // 
            this.labelsalepriceamounts.AutoSize = true;
            this.labelsalepriceamounts.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsalepriceamounts.ForeColor = System.Drawing.Color.MediumSeaGreen;
            this.labelsalepriceamounts.Location = new System.Drawing.Point(75, 48);
            this.labelsalepriceamounts.Name = "labelsalepriceamounts";
            this.labelsalepriceamounts.Size = new System.Drawing.Size(56, 15);
            this.labelsalepriceamounts.TabIndex = 11;
            this.labelsalepriceamounts.Text = "Rs 10.00";
            // 
            // labelsalesprice
            // 
            this.labelsalesprice.AutoSize = true;
            this.labelsalesprice.Location = new System.Drawing.Point(6, 50);
            this.labelsalesprice.Name = "labelsalesprice";
            this.labelsalesprice.Size = new System.Drawing.Size(72, 13);
            this.labelsalesprice.TabIndex = 10;
            this.labelsalesprice.Text = "SALE PRICE:";
            // 
            // paneltranfill
            // 
            this.paneltranfill.BackColor = System.Drawing.Color.White;
            this.paneltranfill.Controls.Add(this.paneltypes);
            this.paneltranfill.Controls.Add(this.paneltransaction);
            this.paneltranfill.Dock = System.Windows.Forms.DockStyle.Fill;
            this.paneltranfill.Location = new System.Drawing.Point(243, 108);
            this.paneltranfill.Name = "paneltranfill";
            this.paneltranfill.Size = new System.Drawing.Size(736, 478);
            this.paneltranfill.TabIndex = 2;
            this.paneltranfill.Paint += new System.Windows.Forms.PaintEventHandler(this.paneltranfill_Paint);
            // 
            // paneltransaction
            // 
            this.paneltransaction.BackColor = System.Drawing.Color.White;
            this.paneltransaction.Controls.Add(this.iconPicboxsearch);
            this.paneltransaction.Controls.Add(this.labeltransactions);
            this.paneltransaction.Controls.Add(this.textBoxsearches);
            this.paneltransaction.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneltransaction.Location = new System.Drawing.Point(0, 0);
            this.paneltransaction.Name = "paneltransaction";
            this.paneltransaction.Size = new System.Drawing.Size(736, 54);
            this.paneltransaction.TabIndex = 0;
            // 
            // labeltransactions
            // 
            this.labeltransactions.AutoSize = true;
            this.labeltransactions.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltransactions.Location = new System.Drawing.Point(15, 19);
            this.labeltransactions.Name = "labeltransactions";
            this.labeltransactions.Size = new System.Drawing.Size(116, 16);
            this.labeltransactions.TabIndex = 1;
            this.labeltransactions.Text = "TRANSACTION";
            // 
            // iconPicboxsearch
            // 
            this.iconPicboxsearch.BackColor = System.Drawing.Color.White;
            this.iconPicboxsearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.iconPicboxsearch.ForeColor = System.Drawing.SystemColors.ControlText;
            this.iconPicboxsearch.IconChar = FontAwesome.Sharp.IconChar.Search;
            this.iconPicboxsearch.IconColor = System.Drawing.SystemColors.ControlText;
            this.iconPicboxsearch.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconPicboxsearch.IconSize = 24;
            this.iconPicboxsearch.Location = new System.Drawing.Point(432, 15);
            this.iconPicboxsearch.Name = "iconPicboxsearch";
            this.iconPicboxsearch.Size = new System.Drawing.Size(24, 25);
            this.iconPicboxsearch.TabIndex = 4;
            this.iconPicboxsearch.TabStop = false;
            // 
            // textBoxsearches
            // 
            this.textBoxsearches.Location = new System.Drawing.Point(456, 15);
            this.textBoxsearches.Multiline = true;
            this.textBoxsearches.Name = "textBoxsearches";
            this.textBoxsearches.Size = new System.Drawing.Size(166, 25);
            this.textBoxsearches.TabIndex = 3;
            // 
            // paneltypes
            // 
            this.paneltypes.Controls.Add(this.iconBtntype);
            this.paneltypes.Controls.Add(this.iconBtnname);
            this.paneltypes.Controls.Add(this.iconBtndate);
            this.paneltypes.Controls.Add(this.iconBtnqty);
            this.paneltypes.Controls.Add(this.iconBtnprice);
            this.paneltypes.Controls.Add(this.iconBtnstatus);
            this.paneltypes.Dock = System.Windows.Forms.DockStyle.Top;
            this.paneltypes.Location = new System.Drawing.Point(0, 54);
            this.paneltypes.Name = "paneltypes";
            this.paneltypes.Size = new System.Drawing.Size(736, 56);
            this.paneltypes.TabIndex = 2;
            // 
            // iconBtntype
            // 
            this.iconBtntype.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtntype.Dock = System.Windows.Forms.DockStyle.Fill;
            this.iconBtntype.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtntype.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtntype.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtntype.IconColor = System.Drawing.Color.Black;
            this.iconBtntype.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtntype.IconSize = 25;
            this.iconBtntype.Location = new System.Drawing.Point(0, 0);
            this.iconBtntype.Name = "iconBtntype";
            this.iconBtntype.Size = new System.Drawing.Size(139, 56);
            this.iconBtntype.TabIndex = 4;
            this.iconBtntype.Text = "TYPE";
            this.iconBtntype.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtntype.UseVisualStyleBackColor = true;
            // 
            // iconBtnname
            // 
            this.iconBtnname.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnname.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtnname.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnname.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnname.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtnname.IconColor = System.Drawing.Color.Black;
            this.iconBtnname.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnname.IconSize = 25;
            this.iconBtnname.Location = new System.Drawing.Point(139, 0);
            this.iconBtnname.Name = "iconBtnname";
            this.iconBtnname.Size = new System.Drawing.Size(158, 56);
            this.iconBtnname.TabIndex = 4;
            this.iconBtnname.Text = "NAME";
            this.iconBtnname.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnname.UseVisualStyleBackColor = true;
            // 
            // iconBtndate
            // 
            this.iconBtndate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtndate.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtndate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtndate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtndate.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtndate.IconColor = System.Drawing.Color.Black;
            this.iconBtndate.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtndate.IconSize = 25;
            this.iconBtndate.Location = new System.Drawing.Point(297, 0);
            this.iconBtndate.Name = "iconBtndate";
            this.iconBtndate.Size = new System.Drawing.Size(107, 56);
            this.iconBtndate.TabIndex = 3;
            this.iconBtndate.Text = "DATE";
            this.iconBtndate.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtndate.UseVisualStyleBackColor = true;
            // 
            // iconBtnqty
            // 
            this.iconBtnqty.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnqty.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtnqty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnqty.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtnqty.IconColor = System.Drawing.Color.Black;
            this.iconBtnqty.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnqty.IconSize = 25;
            this.iconBtnqty.Location = new System.Drawing.Point(404, 0);
            this.iconBtnqty.Name = "iconBtnqty";
            this.iconBtnqty.Size = new System.Drawing.Size(110, 56);
            this.iconBtnqty.TabIndex = 3;
            this.iconBtnqty.Text = "QUANTITY";
            this.iconBtnqty.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnqty.UseVisualStyleBackColor = true;
            // 
            // iconBtnprice
            // 
            this.iconBtnprice.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnprice.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtnprice.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnprice.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtnprice.IconColor = System.Drawing.Color.Black;
            this.iconBtnprice.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnprice.IconSize = 25;
            this.iconBtnprice.Location = new System.Drawing.Point(514, 0);
            this.iconBtnprice.Name = "iconBtnprice";
            this.iconBtnprice.Size = new System.Drawing.Size(116, 56);
            this.iconBtnprice.TabIndex = 2;
            this.iconBtnprice.Text = "PRICE/UNIT";
            this.iconBtnprice.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnprice.UseVisualStyleBackColor = true;
            // 
            // iconBtnstatus
            // 
            this.iconBtnstatus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.iconBtnstatus.Dock = System.Windows.Forms.DockStyle.Right;
            this.iconBtnstatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnstatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iconBtnstatus.IconChar = FontAwesome.Sharp.IconChar.Filter;
            this.iconBtnstatus.IconColor = System.Drawing.Color.Black;
            this.iconBtnstatus.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnstatus.IconSize = 25;
            this.iconBtnstatus.Location = new System.Drawing.Point(630, 0);
            this.iconBtnstatus.Name = "iconBtnstatus";
            this.iconBtnstatus.Size = new System.Drawing.Size(106, 56);
            this.iconBtnstatus.TabIndex = 1;
            this.iconBtnstatus.Text = "STATUS";
            this.iconBtnstatus.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.iconBtnstatus.UseVisualStyleBackColor = true;
            // 
            // serviceusercontrol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.paneltranfill);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.paneladdservice);
            this.Name = "serviceusercontrol";
            this.Size = new System.Drawing.Size(979, 586);
            this.paneladdservice.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.iconpicturesearch)).EndInit();
            this.panelsearch.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.paneltranfill.ResumeLayout(false);
            this.paneltransaction.ResumeLayout(false);
            this.paneltransaction.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.iconPicboxsearch)).EndInit();
            this.paneltypes.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel paneladdservice;
        private FontAwesome.Sharp.IconButton iconBtnaddservices;
        private FontAwesome.Sharp.IconButton iconBtndownarrow;
        private FontAwesome.Sharp.IconPictureBox iconpicturesearch;
        private FontAwesome.Sharp.IconButton iconBtnitem;
        private System.Windows.Forms.Panel panelsearch;
        private System.Windows.Forms.Panel panel2;
        private FontAwesome.Sharp.IconButton iconBtnitemsname;
        private System.Windows.Forms.Label labelsalepriceamounts;
        private System.Windows.Forms.Label labelsalesprice;
        private System.Windows.Forms.Panel paneltranfill;
        private System.Windows.Forms.Panel paneltransaction;
        private System.Windows.Forms.Label labeltransactions;
        private FontAwesome.Sharp.IconPictureBox iconPicboxsearch;
        private System.Windows.Forms.TextBox textBoxsearches;
        private System.Windows.Forms.Panel paneltypes;
        private FontAwesome.Sharp.IconButton iconBtntype;
        private FontAwesome.Sharp.IconButton iconBtnname;
        private FontAwesome.Sharp.IconButton iconBtndate;
        private FontAwesome.Sharp.IconButton iconBtnqty;
        private FontAwesome.Sharp.IconButton iconBtnprice;
        private FontAwesome.Sharp.IconButton iconBtnstatus;
    }
}
