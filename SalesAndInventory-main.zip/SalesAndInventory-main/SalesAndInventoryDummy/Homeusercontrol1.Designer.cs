﻿namespace SalesAndInventoryDummy
{
    partial class Homeusercontrol1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelmainprivacy = new System.Windows.Forms.Panel();
            this.paneldeliverychallan = new System.Windows.Forms.Panel();
            this.labeldelivery0 = new System.Windows.Forms.Label();
            this.labeldeliverychallan = new System.Windows.Forms.Label();
            this.labelnoofchallanzero = new System.Windows.Forms.Label();
            this.labelnoofchallans = new System.Windows.Forms.Label();
            this.labeldeliverychallans = new System.Windows.Forms.Label();
            this.panelsaleorders = new System.Windows.Forms.Panel();
            this.labelopenzero = new System.Windows.Forms.Label();
            this.labelnoofzero = new System.Windows.Forms.Label();
            this.labelopensale = new System.Windows.Forms.Label();
            this.labelnoofopenorders = new System.Windows.Forms.Label();
            this.labelsaleorders = new System.Windows.Forms.Label();
            this.labelsales = new System.Windows.Forms.Label();
            this.panelloanacc = new System.Windows.Forms.Panel();
            this.labelloanpointzero = new System.Windows.Forms.Label();
            this.labelloanaacounts = new System.Windows.Forms.Label();
            this.labelloanrs = new System.Windows.Forms.Label();
            this.panelstockvalue = new System.Windows.Forms.Panel();
            this.labelbankaccpointzero = new System.Windows.Forms.Label();
            this.labelbankaccounts = new System.Windows.Forms.Label();
            this.labelbankaccrs = new System.Windows.Forms.Label();
            this.panelcashinhand = new System.Windows.Forms.Panel();
            this.labelcashinpointzero = new System.Windows.Forms.Label();
            this.labelchashinhand = new System.Windows.Forms.Label();
            this.labelcashrs = new System.Windows.Forms.Label();
            this.labelcashandbank = new System.Windows.Forms.Label();
            this.panellowstocks = new System.Windows.Forms.Panel();
            this.labelfrontsw2 = new System.Windows.Forms.Label();
            this.labelfrontsw1 = new System.Windows.Forms.Label();
            this.labelsw2 = new System.Windows.Forms.Label();
            this.labelsw1 = new System.Windows.Forms.Label();
            this.labellowstock = new System.Windows.Forms.Label();
            this.panelstockinventory = new System.Windows.Forms.Panel();
            this.labelstkpointzero = new System.Windows.Forms.Label();
            this.labelstockvalue = new System.Windows.Forms.Label();
            this.labelstkrs = new System.Windows.Forms.Label();
            this.labelstockinventory = new System.Windows.Forms.Label();
            this.panelprivacy = new System.Windows.Forms.Panel();
            this.labelprivacy = new System.Windows.Forms.Label();
            this.panelmainn = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panelexpenses2 = new System.Windows.Forms.Panel();
            this.labelrszeroo = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.labelthismont = new System.Windows.Forms.Label();
            this.labelexpenses = new System.Windows.Forms.Label();
            this.panelsale1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.labelrs = new System.Windows.Forms.Label();
            this.labelthismonth = new System.Windows.Forms.Label();
            this.labeltotalsale = new System.Windows.Forms.Label();
            this.labelzeropercent = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.labelsale = new System.Windows.Forms.Label();
            this.panelpurchase5 = new System.Windows.Forms.Panel();
            this.labeltime = new System.Windows.Forms.Label();
            this.labelpurchasethismonth = new System.Windows.Forms.Label();
            this.labelitemsentered = new System.Windows.Forms.Label();
            this.labelyouhave = new System.Windows.Forms.Label();
            this.labelpurpointzero = new System.Windows.Forms.Label();
            this.labelpurchaserszero = new System.Windows.Forms.Label();
            this.labelpurchasee = new System.Windows.Forms.Label();
            this.panelyoupay4 = new System.Windows.Forms.Panel();
            this.labelamount = new System.Windows.Forms.Label();
            this.labelyoudonthaveany = new System.Windows.Forms.Label();
            this.labelyoupointzerozero = new System.Windows.Forms.Label();
            this.labelyouwillrszerozero = new System.Windows.Forms.Label();
            this.labelyouwillpay = new System.Windows.Forms.Label();
            this.panelyoureceive3 = new System.Windows.Forms.Panel();
            this.labelamounttobe = new System.Windows.Forms.Label();
            this.labelyoudonthave = new System.Windows.Forms.Label();
            this.labelyourecpointzero = new System.Windows.Forms.Label();
            this.labelyourecrszero = new System.Windows.Forms.Label();
            this.labelyoureceive = new System.Windows.Forms.Label();
            this.panelmainprivacy.SuspendLayout();
            this.paneldeliverychallan.SuspendLayout();
            this.panelsaleorders.SuspendLayout();
            this.panelloanacc.SuspendLayout();
            this.panelstockvalue.SuspendLayout();
            this.panelcashinhand.SuspendLayout();
            this.panellowstocks.SuspendLayout();
            this.panelstockinventory.SuspendLayout();
            this.panelprivacy.SuspendLayout();
            this.panelmainn.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelexpenses2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panelsale1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panelpurchase5.SuspendLayout();
            this.panelyoupay4.SuspendLayout();
            this.panelyoureceive3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panelmainprivacy
            // 
            this.panelmainprivacy.Controls.Add(this.paneldeliverychallan);
            this.panelmainprivacy.Controls.Add(this.panelsaleorders);
            this.panelmainprivacy.Controls.Add(this.labelsales);
            this.panelmainprivacy.Controls.Add(this.panelloanacc);
            this.panelmainprivacy.Controls.Add(this.panelstockvalue);
            this.panelmainprivacy.Controls.Add(this.panelcashinhand);
            this.panelmainprivacy.Controls.Add(this.labelcashandbank);
            this.panelmainprivacy.Controls.Add(this.panellowstocks);
            this.panelmainprivacy.Controls.Add(this.panelstockinventory);
            this.panelmainprivacy.Controls.Add(this.labelstockinventory);
            this.panelmainprivacy.Controls.Add(this.panelprivacy);
            this.panelmainprivacy.Dock = System.Windows.Forms.DockStyle.Right;
            this.panelmainprivacy.Location = new System.Drawing.Point(781, 0);
            this.panelmainprivacy.Name = "panelmainprivacy";
            this.panelmainprivacy.Size = new System.Drawing.Size(268, 642);
            this.panelmainprivacy.TabIndex = 2;
            // 
            // paneldeliverychallan
            // 
            this.paneldeliverychallan.BackColor = System.Drawing.Color.White;
            this.paneldeliverychallan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.paneldeliverychallan.Controls.Add(this.labeldelivery0);
            this.paneldeliverychallan.Controls.Add(this.labeldeliverychallan);
            this.paneldeliverychallan.Controls.Add(this.labelnoofchallanzero);
            this.paneldeliverychallan.Controls.Add(this.labelnoofchallans);
            this.paneldeliverychallan.Controls.Add(this.labeldeliverychallans);
            this.paneldeliverychallan.Location = new System.Drawing.Point(0, 540);
            this.paneldeliverychallan.Name = "paneldeliverychallan";
            this.paneldeliverychallan.Size = new System.Drawing.Size(230, 71);
            this.paneldeliverychallan.TabIndex = 14;
            // 
            // labeldelivery0
            // 
            this.labeldelivery0.AutoSize = true;
            this.labeldelivery0.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldelivery0.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labeldelivery0.Location = new System.Drawing.Point(207, 45);
            this.labeldelivery0.Name = "labeldelivery0";
            this.labeldelivery0.Size = new System.Drawing.Size(16, 18);
            this.labeldelivery0.TabIndex = 13;
            this.labeldelivery0.Text = "0";
            // 
            // labeldeliverychallan
            // 
            this.labeldeliverychallan.AutoSize = true;
            this.labeldeliverychallan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldeliverychallan.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labeldeliverychallan.Location = new System.Drawing.Point(11, 45);
            this.labeldeliverychallan.Name = "labeldeliverychallan";
            this.labeldeliverychallan.Size = new System.Drawing.Size(168, 18);
            this.labeldeliverychallan.TabIndex = 8;
            this.labeldeliverychallan.Text = "Delivery Challan Amount";
            // 
            // labelnoofchallanzero
            // 
            this.labelnoofchallanzero.AutoSize = true;
            this.labelnoofchallanzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnoofchallanzero.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelnoofchallanzero.Location = new System.Drawing.Point(207, 27);
            this.labelnoofchallanzero.Name = "labelnoofchallanzero";
            this.labelnoofchallanzero.Size = new System.Drawing.Size(16, 18);
            this.labelnoofchallanzero.TabIndex = 12;
            this.labelnoofchallanzero.Text = "0";
            // 
            // labelnoofchallans
            // 
            this.labelnoofchallans.AutoSize = true;
            this.labelnoofchallans.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnoofchallans.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelnoofchallans.Location = new System.Drawing.Point(11, 26);
            this.labelnoofchallans.Name = "labelnoofchallans";
            this.labelnoofchallans.Size = new System.Drawing.Size(146, 18);
            this.labelnoofchallans.TabIndex = 5;
            this.labelnoofchallans.Text = "No of Open Challans";
            // 
            // labeldeliverychallans
            // 
            this.labeldeliverychallans.AutoSize = true;
            this.labeldeliverychallans.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldeliverychallans.Location = new System.Drawing.Point(9, 1);
            this.labeldeliverychallans.Name = "labeldeliverychallans";
            this.labeldeliverychallans.Size = new System.Drawing.Size(121, 18);
            this.labeldeliverychallans.TabIndex = 7;
            this.labeldeliverychallans.Text = "Delivery Challans";
            // 
            // panelsaleorders
            // 
            this.panelsaleorders.BackColor = System.Drawing.Color.White;
            this.panelsaleorders.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelsaleorders.Controls.Add(this.labelopenzero);
            this.panelsaleorders.Controls.Add(this.labelnoofzero);
            this.panelsaleorders.Controls.Add(this.labelopensale);
            this.panelsaleorders.Controls.Add(this.labelnoofopenorders);
            this.panelsaleorders.Controls.Add(this.labelsaleorders);
            this.panelsaleorders.Location = new System.Drawing.Point(0, 444);
            this.panelsaleorders.Name = "panelsaleorders";
            this.panelsaleorders.Size = new System.Drawing.Size(230, 76);
            this.panelsaleorders.TabIndex = 10;
            // 
            // labelopenzero
            // 
            this.labelopenzero.AutoSize = true;
            this.labelopenzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelopenzero.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelopenzero.Location = new System.Drawing.Point(205, 45);
            this.labelopenzero.Name = "labelopenzero";
            this.labelopenzero.Size = new System.Drawing.Size(16, 18);
            this.labelopenzero.TabIndex = 10;
            this.labelopenzero.Text = "0";
            // 
            // labelnoofzero
            // 
            this.labelnoofzero.AutoSize = true;
            this.labelnoofzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnoofzero.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelnoofzero.Location = new System.Drawing.Point(205, 27);
            this.labelnoofzero.Name = "labelnoofzero";
            this.labelnoofzero.Size = new System.Drawing.Size(16, 18);
            this.labelnoofzero.TabIndex = 9;
            this.labelnoofzero.Text = "0";
            // 
            // labelopensale
            // 
            this.labelopensale.AutoSize = true;
            this.labelopensale.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelopensale.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelopensale.Location = new System.Drawing.Point(11, 45);
            this.labelopensale.Name = "labelopensale";
            this.labelopensale.Size = new System.Drawing.Size(182, 18);
            this.labelopensale.TabIndex = 8;
            this.labelopensale.Text = "Open Sale Orders Amount";
            // 
            // labelnoofopenorders
            // 
            this.labelnoofopenorders.AutoSize = true;
            this.labelnoofopenorders.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelnoofopenorders.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelnoofopenorders.Location = new System.Drawing.Point(11, 27);
            this.labelnoofopenorders.Name = "labelnoofopenorders";
            this.labelnoofopenorders.Size = new System.Drawing.Size(135, 18);
            this.labelnoofopenorders.TabIndex = 5;
            this.labelnoofopenorders.Text = "No of Open Orders";
            // 
            // labelsaleorders
            // 
            this.labelsaleorders.AutoSize = true;
            this.labelsaleorders.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsaleorders.Location = new System.Drawing.Point(9, 1);
            this.labelsaleorders.Name = "labelsaleorders";
            this.labelsaleorders.Size = new System.Drawing.Size(87, 18);
            this.labelsaleorders.TabIndex = 7;
            this.labelsaleorders.Text = "Sale Orders";
            // 
            // labelsales
            // 
            this.labelsales.AutoSize = true;
            this.labelsales.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsales.Location = new System.Drawing.Point(0, 415);
            this.labelsales.Name = "labelsales";
            this.labelsales.Size = new System.Drawing.Size(49, 20);
            this.labelsales.TabIndex = 9;
            this.labelsales.Text = "Sales";
            // 
            // panelloanacc
            // 
            this.panelloanacc.BackColor = System.Drawing.Color.White;
            this.panelloanacc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelloanacc.Controls.Add(this.labelloanpointzero);
            this.panelloanacc.Controls.Add(this.labelloanaacounts);
            this.panelloanacc.Controls.Add(this.labelloanrs);
            this.panelloanacc.Location = new System.Drawing.Point(0, 358);
            this.panelloanacc.Name = "panelloanacc";
            this.panelloanacc.Size = new System.Drawing.Size(230, 48);
            this.panelloanacc.TabIndex = 8;
            // 
            // labelloanpointzero
            // 
            this.labelloanpointzero.AutoSize = true;
            this.labelloanpointzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelloanpointzero.Location = new System.Drawing.Point(60, 23);
            this.labelloanpointzero.Name = "labelloanpointzero";
            this.labelloanpointzero.Size = new System.Drawing.Size(28, 18);
            this.labelloanpointzero.TabIndex = 5;
            this.labelloanpointzero.Text = ".00";
            // 
            // labelloanaacounts
            // 
            this.labelloanaacounts.AutoSize = true;
            this.labelloanaacounts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelloanaacounts.Location = new System.Drawing.Point(9, 1);
            this.labelloanaacounts.Name = "labelloanaacounts";
            this.labelloanaacounts.Size = new System.Drawing.Size(107, 18);
            this.labelloanaacounts.TabIndex = 7;
            this.labelloanaacounts.Text = "Loan Accounts";
            // 
            // labelloanrs
            // 
            this.labelloanrs.AutoSize = true;
            this.labelloanrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelloanrs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.labelloanrs.Location = new System.Drawing.Point(9, 22);
            this.labelloanrs.Name = "labelloanrs";
            this.labelloanrs.Size = new System.Drawing.Size(56, 20);
            this.labelloanrs.TabIndex = 4;
            this.labelloanrs.Text = "Rs 00";
            // 
            // panelstockvalue
            // 
            this.panelstockvalue.BackColor = System.Drawing.Color.White;
            this.panelstockvalue.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelstockvalue.Controls.Add(this.labelbankaccpointzero);
            this.panelstockvalue.Controls.Add(this.labelbankaccounts);
            this.panelstockvalue.Controls.Add(this.labelbankaccrs);
            this.panelstockvalue.Location = new System.Drawing.Point(0, 299);
            this.panelstockvalue.Name = "panelstockvalue";
            this.panelstockvalue.Size = new System.Drawing.Size(230, 48);
            this.panelstockvalue.TabIndex = 7;
            // 
            // labelbankaccpointzero
            // 
            this.labelbankaccpointzero.AutoSize = true;
            this.labelbankaccpointzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelbankaccpointzero.Location = new System.Drawing.Point(60, 23);
            this.labelbankaccpointzero.Name = "labelbankaccpointzero";
            this.labelbankaccpointzero.Size = new System.Drawing.Size(28, 18);
            this.labelbankaccpointzero.TabIndex = 5;
            this.labelbankaccpointzero.Text = ".00";
            // 
            // labelbankaccounts
            // 
            this.labelbankaccounts.AutoSize = true;
            this.labelbankaccounts.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelbankaccounts.Location = new System.Drawing.Point(9, 1);
            this.labelbankaccounts.Name = "labelbankaccounts";
            this.labelbankaccounts.Size = new System.Drawing.Size(108, 18);
            this.labelbankaccounts.TabIndex = 7;
            this.labelbankaccounts.Text = "Bank Accounts";
            // 
            // labelbankaccrs
            // 
            this.labelbankaccrs.AutoSize = true;
            this.labelbankaccrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelbankaccrs.Location = new System.Drawing.Point(9, 22);
            this.labelbankaccrs.Name = "labelbankaccrs";
            this.labelbankaccrs.Size = new System.Drawing.Size(56, 20);
            this.labelbankaccrs.TabIndex = 4;
            this.labelbankaccrs.Text = "Rs 00";
            // 
            // panelcashinhand
            // 
            this.panelcashinhand.BackColor = System.Drawing.Color.White;
            this.panelcashinhand.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelcashinhand.Controls.Add(this.labelcashinpointzero);
            this.panelcashinhand.Controls.Add(this.labelchashinhand);
            this.panelcashinhand.Controls.Add(this.labelcashrs);
            this.panelcashinhand.Location = new System.Drawing.Point(0, 239);
            this.panelcashinhand.Name = "panelcashinhand";
            this.panelcashinhand.Size = new System.Drawing.Size(230, 48);
            this.panelcashinhand.TabIndex = 6;
            // 
            // labelcashinpointzero
            // 
            this.labelcashinpointzero.AutoSize = true;
            this.labelcashinpointzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcashinpointzero.Location = new System.Drawing.Point(60, 23);
            this.labelcashinpointzero.Name = "labelcashinpointzero";
            this.labelcashinpointzero.Size = new System.Drawing.Size(28, 18);
            this.labelcashinpointzero.TabIndex = 5;
            this.labelcashinpointzero.Text = ".00";
            // 
            // labelchashinhand
            // 
            this.labelchashinhand.AutoSize = true;
            this.labelchashinhand.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelchashinhand.Location = new System.Drawing.Point(9, 1);
            this.labelchashinhand.Name = "labelchashinhand";
            this.labelchashinhand.Size = new System.Drawing.Size(97, 18);
            this.labelchashinhand.TabIndex = 7;
            this.labelchashinhand.Text = "Cash in Hand";
            // 
            // labelcashrs
            // 
            this.labelcashrs.AutoSize = true;
            this.labelcashrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcashrs.ForeColor = System.Drawing.Color.ForestGreen;
            this.labelcashrs.Location = new System.Drawing.Point(9, 22);
            this.labelcashrs.Name = "labelcashrs";
            this.labelcashrs.Size = new System.Drawing.Size(56, 20);
            this.labelcashrs.TabIndex = 4;
            this.labelcashrs.Text = "Rs 55";
            // 
            // labelcashandbank
            // 
            this.labelcashandbank.AutoSize = true;
            this.labelcashandbank.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelcashandbank.Location = new System.Drawing.Point(-1, 209);
            this.labelcashandbank.Name = "labelcashandbank";
            this.labelcashandbank.Size = new System.Drawing.Size(118, 20);
            this.labelcashandbank.TabIndex = 5;
            this.labelcashandbank.Text = "Cash and Bank";
            // 
            // panellowstocks
            // 
            this.panellowstocks.BackColor = System.Drawing.Color.White;
            this.panellowstocks.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panellowstocks.Controls.Add(this.labelfrontsw2);
            this.panellowstocks.Controls.Add(this.labelfrontsw1);
            this.panellowstocks.Controls.Add(this.labelsw2);
            this.panellowstocks.Controls.Add(this.labelsw1);
            this.panellowstocks.Controls.Add(this.labellowstock);
            this.panellowstocks.Location = new System.Drawing.Point(0, 126);
            this.panellowstocks.Name = "panellowstocks";
            this.panellowstocks.Size = new System.Drawing.Size(230, 76);
            this.panellowstocks.TabIndex = 4;
            // 
            // labelfrontsw2
            // 
            this.labelfrontsw2.AutoSize = true;
            this.labelfrontsw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelfrontsw2.ForeColor = System.Drawing.Color.Red;
            this.labelfrontsw2.Location = new System.Drawing.Point(205, 45);
            this.labelfrontsw2.Name = "labelfrontsw2";
            this.labelfrontsw2.Size = new System.Drawing.Size(21, 18);
            this.labelfrontsw2.TabIndex = 15;
            this.labelfrontsw2.Text = "-1";
            // 
            // labelfrontsw1
            // 
            this.labelfrontsw1.AutoSize = true;
            this.labelfrontsw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelfrontsw1.ForeColor = System.Drawing.Color.Red;
            this.labelfrontsw1.Location = new System.Drawing.Point(205, 27);
            this.labelfrontsw1.Name = "labelfrontsw1";
            this.labelfrontsw1.Size = new System.Drawing.Size(21, 18);
            this.labelfrontsw1.TabIndex = 14;
            this.labelfrontsw1.Text = "-1";
            // 
            // labelsw2
            // 
            this.labelsw2.AutoSize = true;
            this.labelsw2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsw2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelsw2.Location = new System.Drawing.Point(11, 45);
            this.labelsw2.Name = "labelsw2";
            this.labelsw2.Size = new System.Drawing.Size(35, 18);
            this.labelsw2.TabIndex = 8;
            this.labelsw2.Text = "sw2";
            // 
            // labelsw1
            // 
            this.labelsw1.AutoSize = true;
            this.labelsw1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsw1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.labelsw1.Location = new System.Drawing.Point(11, 27);
            this.labelsw1.Name = "labelsw1";
            this.labelsw1.Size = new System.Drawing.Size(35, 18);
            this.labelsw1.TabIndex = 5;
            this.labelsw1.Text = "sw1";
            this.labelsw1.Click += new System.EventHandler(this.label3_Click);
            // 
            // labellowstock
            // 
            this.labellowstock.AutoSize = true;
            this.labellowstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labellowstock.Location = new System.Drawing.Point(9, 1);
            this.labellowstock.Name = "labellowstock";
            this.labellowstock.Size = new System.Drawing.Size(87, 18);
            this.labellowstock.TabIndex = 7;
            this.labellowstock.Text = "Stock Value";
            // 
            // panelstockinventory
            // 
            this.panelstockinventory.BackColor = System.Drawing.Color.White;
            this.panelstockinventory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelstockinventory.Controls.Add(this.labelstkpointzero);
            this.panelstockinventory.Controls.Add(this.labelstockvalue);
            this.panelstockinventory.Controls.Add(this.labelstkrs);
            this.panelstockinventory.Location = new System.Drawing.Point(0, 68);
            this.panelstockinventory.Name = "panelstockinventory";
            this.panelstockinventory.Size = new System.Drawing.Size(230, 48);
            this.panelstockinventory.TabIndex = 3;
            // 
            // labelstkpointzero
            // 
            this.labelstkpointzero.AutoSize = true;
            this.labelstkpointzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelstkpointzero.Location = new System.Drawing.Point(60, 23);
            this.labelstkpointzero.Name = "labelstkpointzero";
            this.labelstkpointzero.Size = new System.Drawing.Size(28, 18);
            this.labelstkpointzero.TabIndex = 5;
            this.labelstkpointzero.Text = ".00";
            // 
            // labelstockvalue
            // 
            this.labelstockvalue.AutoSize = true;
            this.labelstockvalue.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelstockvalue.Location = new System.Drawing.Point(9, 1);
            this.labelstockvalue.Name = "labelstockvalue";
            this.labelstockvalue.Size = new System.Drawing.Size(87, 18);
            this.labelstockvalue.TabIndex = 7;
            this.labelstockvalue.Text = "Stock Value";
            // 
            // labelstkrs
            // 
            this.labelstkrs.AutoSize = true;
            this.labelstkrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelstkrs.Location = new System.Drawing.Point(9, 22);
            this.labelstkrs.Name = "labelstkrs";
            this.labelstkrs.Size = new System.Drawing.Size(56, 20);
            this.labelstkrs.TabIndex = 4;
            this.labelstkrs.Text = "Rs 00";
            // 
            // labelstockinventory
            // 
            this.labelstockinventory.AutoSize = true;
            this.labelstockinventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelstockinventory.Location = new System.Drawing.Point(0, 45);
            this.labelstockinventory.Name = "labelstockinventory";
            this.labelstockinventory.Size = new System.Drawing.Size(119, 20);
            this.labelstockinventory.TabIndex = 2;
            this.labelstockinventory.Text = "Stock Inventory";
            // 
            // panelprivacy
            // 
            this.panelprivacy.BackColor = System.Drawing.Color.White;
            this.panelprivacy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelprivacy.Controls.Add(this.labelprivacy);
            this.panelprivacy.Location = new System.Drawing.Point(0, 3);
            this.panelprivacy.Name = "panelprivacy";
            this.panelprivacy.Size = new System.Drawing.Size(230, 40);
            this.panelprivacy.TabIndex = 0;
            // 
            // labelprivacy
            // 
            this.labelprivacy.AutoSize = true;
            this.labelprivacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelprivacy.Location = new System.Drawing.Point(9, 10);
            this.labelprivacy.Name = "labelprivacy";
            this.labelprivacy.Size = new System.Drawing.Size(56, 18);
            this.labelprivacy.TabIndex = 6;
            this.labelprivacy.Text = "Privacy";
            // 
            // panelmainn
            // 
            this.panelmainn.Controls.Add(this.panel1);
            this.panelmainn.Controls.Add(this.panelpurchase5);
            this.panelmainn.Controls.Add(this.panelyoupay4);
            this.panelmainn.Controls.Add(this.panelyoureceive3);
            this.panelmainn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelmainn.Location = new System.Drawing.Point(0, 0);
            this.panelmainn.Name = "panelmainn";
            this.panelmainn.Padding = new System.Windows.Forms.Padding(10);
            this.panelmainn.Size = new System.Drawing.Size(781, 642);
            this.panelmainn.TabIndex = 3;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panelexpenses2);
            this.panel1.Controls.Add(this.panelsale1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(10, 10);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(761, 180);
            this.panel1.TabIndex = 5;
            // 
            // panelexpenses2
            // 
            this.panelexpenses2.BackColor = System.Drawing.Color.White;
            this.panelexpenses2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelexpenses2.Controls.Add(this.labelrszeroo);
            this.panelexpenses2.Controls.Add(this.panel5);
            this.panelexpenses2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelexpenses2.Location = new System.Drawing.Point(452, 0);
            this.panelexpenses2.Name = "panelexpenses2";
            this.panelexpenses2.Size = new System.Drawing.Size(309, 180);
            this.panelexpenses2.TabIndex = 3;
            // 
            // labelrszeroo
            // 
            this.labelrszeroo.AutoSize = true;
            this.labelrszeroo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelrszeroo.Location = new System.Drawing.Point(9, 50);
            this.labelrszeroo.Name = "labelrszeroo";
            this.labelrszeroo.Size = new System.Drawing.Size(56, 20);
            this.labelrszeroo.TabIndex = 1;
            this.labelrszeroo.Text = "Rs 00";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.labelthismont);
            this.panel5.Controls.Add(this.labelexpenses);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Padding = new System.Windows.Forms.Padding(10);
            this.panel5.Size = new System.Drawing.Size(307, 32);
            this.panel5.TabIndex = 4;
            // 
            // labelthismont
            // 
            this.labelthismont.AutoSize = true;
            this.labelthismont.Dock = System.Windows.Forms.DockStyle.Right;
            this.labelthismont.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelthismont.Location = new System.Drawing.Point(215, 10);
            this.labelthismont.Name = "labelthismont";
            this.labelthismont.Size = new System.Drawing.Size(82, 18);
            this.labelthismont.TabIndex = 3;
            this.labelthismont.Text = "This Month";
            // 
            // labelexpenses
            // 
            this.labelexpenses.AutoSize = true;
            this.labelexpenses.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelexpenses.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelexpenses.Location = new System.Drawing.Point(10, 10);
            this.labelexpenses.Name = "labelexpenses";
            this.labelexpenses.Size = new System.Drawing.Size(73, 18);
            this.labelexpenses.TabIndex = 0;
            this.labelexpenses.Text = "Expenses";
            // 
            // panelsale1
            // 
            this.panelsale1.BackColor = System.Drawing.Color.White;
            this.panelsale1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelsale1.Controls.Add(this.panel4);
            this.panelsale1.Controls.Add(this.panel3);
            this.panelsale1.Controls.Add(this.panel2);
            this.panelsale1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelsale1.Location = new System.Drawing.Point(0, 0);
            this.panelsale1.Name = "panelsale1";
            this.panelsale1.Size = new System.Drawing.Size(452, 180);
            this.panelsale1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(192, 32);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(258, 146);
            this.panel4.TabIndex = 8;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.labelrs);
            this.panel3.Controls.Add(this.labelthismonth);
            this.panel3.Controls.Add(this.labeltotalsale);
            this.panel3.Controls.Add(this.labelzeropercent);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 32);
            this.panel3.Name = "panel3";
            this.panel3.Padding = new System.Windows.Forms.Padding(10);
            this.panel3.Size = new System.Drawing.Size(192, 146);
            this.panel3.TabIndex = 7;
            // 
            // labelrs
            // 
            this.labelrs.AutoSize = true;
            this.labelrs.Dock = System.Windows.Forms.DockStyle.Top;
            this.labelrs.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelrs.Location = new System.Drawing.Point(10, 38);
            this.labelrs.Name = "labelrs";
            this.labelrs.Size = new System.Drawing.Size(56, 20);
            this.labelrs.TabIndex = 1;
            this.labelrs.Text = "Rs 55";
            // 
            // labelthismonth
            // 
            this.labelthismonth.AutoSize = true;
            this.labelthismonth.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelthismonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelthismonth.Location = new System.Drawing.Point(10, 90);
            this.labelthismonth.Name = "labelthismonth";
            this.labelthismonth.Size = new System.Drawing.Size(135, 18);
            this.labelthismonth.TabIndex = 5;
            this.labelthismonth.Text = "This Month Growth";
            // 
            // labeltotalsale
            // 
            this.labeltotalsale.AutoSize = true;
            this.labeltotalsale.Dock = System.Windows.Forms.DockStyle.Top;
            this.labeltotalsale.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltotalsale.Location = new System.Drawing.Point(10, 10);
            this.labeltotalsale.Name = "labeltotalsale";
            this.labeltotalsale.Padding = new System.Windows.Forms.Padding(0, 0, 0, 10);
            this.labeltotalsale.Size = new System.Drawing.Size(113, 28);
            this.labeltotalsale.TabIndex = 3;
            this.labeltotalsale.Text = "Total Sale (Aug)";
            // 
            // labelzeropercent
            // 
            this.labelzeropercent.AutoSize = true;
            this.labelzeropercent.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.labelzeropercent.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelzeropercent.Location = new System.Drawing.Point(10, 108);
            this.labelzeropercent.Name = "labelzeropercent";
            this.labelzeropercent.Padding = new System.Windows.Forms.Padding(0, 10, 0, 0);
            this.labelzeropercent.Size = new System.Drawing.Size(29, 28);
            this.labelzeropercent.TabIndex = 4;
            this.labelzeropercent.Text = "0%";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.labelsale);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Padding = new System.Windows.Forms.Padding(10);
            this.panel2.Size = new System.Drawing.Size(450, 32);
            this.panel2.TabIndex = 6;
            // 
            // labelsale
            // 
            this.labelsale.AutoSize = true;
            this.labelsale.Dock = System.Windows.Forms.DockStyle.Left;
            this.labelsale.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelsale.Location = new System.Drawing.Point(10, 10);
            this.labelsale.Name = "labelsale";
            this.labelsale.Size = new System.Drawing.Size(37, 18);
            this.labelsale.TabIndex = 0;
            this.labelsale.Text = "Sale";
            // 
            // panelpurchase5
            // 
            this.panelpurchase5.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelpurchase5.BackColor = System.Drawing.Color.White;
            this.panelpurchase5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelpurchase5.Controls.Add(this.labeltime);
            this.panelpurchase5.Controls.Add(this.labelpurchasethismonth);
            this.panelpurchase5.Controls.Add(this.labelitemsentered);
            this.panelpurchase5.Controls.Add(this.labelyouhave);
            this.panelpurchase5.Controls.Add(this.labelpurpointzero);
            this.panelpurchase5.Controls.Add(this.labelpurchaserszero);
            this.panelpurchase5.Controls.Add(this.labelpurchasee);
            this.panelpurchase5.Location = new System.Drawing.Point(499, 448);
            this.panelpurchase5.Name = "panelpurchase5";
            this.panelpurchase5.Size = new System.Drawing.Size(239, 191);
            this.panelpurchase5.TabIndex = 4;
            // 
            // labeltime
            // 
            this.labeltime.AutoSize = true;
            this.labeltime.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeltime.Location = new System.Drawing.Point(100, 151);
            this.labeltime.Name = "labeltime";
            this.labeltime.Size = new System.Drawing.Size(40, 18);
            this.labeltime.TabIndex = 7;
            this.labeltime.Text = "time.";
            // 
            // labelpurchasethismonth
            // 
            this.labelpurchasethismonth.AutoSize = true;
            this.labelpurchasethismonth.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpurchasethismonth.Location = new System.Drawing.Point(139, 9);
            this.labelpurchasethismonth.Name = "labelpurchasethismonth";
            this.labelpurchasethismonth.Size = new System.Drawing.Size(82, 18);
            this.labelpurchasethismonth.TabIndex = 6;
            this.labelpurchasethismonth.Text = "This Month";
            // 
            // labelitemsentered
            // 
            this.labelitemsentered.AutoSize = true;
            this.labelitemsentered.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelitemsentered.Location = new System.Drawing.Point(32, 133);
            this.labelitemsentered.Name = "labelitemsentered";
            this.labelitemsentered.Size = new System.Drawing.Size(178, 18);
            this.labelitemsentered.TabIndex = 5;
            this.labelitemsentered.Text = "items entered for selected";
            // 
            // labelyouhave
            // 
            this.labelyouhave.AutoSize = true;
            this.labelyouhave.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyouhave.Location = new System.Drawing.Point(32, 115);
            this.labelyouhave.Name = "labelyouhave";
            this.labelyouhave.Size = new System.Drawing.Size(163, 18);
            this.labelyouhave.TabIndex = 3;
            this.labelyouhave.Text = "You have no purchased";
            // 
            // labelpurpointzero
            // 
            this.labelpurpointzero.AutoSize = true;
            this.labelpurpointzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpurpointzero.Location = new System.Drawing.Point(64, 40);
            this.labelpurpointzero.Name = "labelpurpointzero";
            this.labelpurpointzero.Size = new System.Drawing.Size(28, 18);
            this.labelpurpointzero.TabIndex = 2;
            this.labelpurpointzero.Text = ".00";
            // 
            // labelpurchaserszero
            // 
            this.labelpurchaserszero.AutoSize = true;
            this.labelpurchaserszero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpurchaserszero.Location = new System.Drawing.Point(13, 39);
            this.labelpurchaserszero.Name = "labelpurchaserszero";
            this.labelpurchaserszero.Size = new System.Drawing.Size(56, 20);
            this.labelpurchaserszero.TabIndex = 1;
            this.labelpurchaserszero.Text = "Rs 00";
            // 
            // labelpurchasee
            // 
            this.labelpurchasee.AutoSize = true;
            this.labelpurchasee.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpurchasee.Location = new System.Drawing.Point(14, 9);
            this.labelpurchasee.Name = "labelpurchasee";
            this.labelpurchasee.Size = new System.Drawing.Size(71, 18);
            this.labelpurchasee.TabIndex = 0;
            this.labelpurchasee.Text = "Purchase";
            // 
            // panelyoupay4
            // 
            this.panelyoupay4.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelyoupay4.BackColor = System.Drawing.Color.White;
            this.panelyoupay4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelyoupay4.Controls.Add(this.labelamount);
            this.panelyoupay4.Controls.Add(this.labelyoudonthaveany);
            this.panelyoupay4.Controls.Add(this.labelyoupointzerozero);
            this.panelyoupay4.Controls.Add(this.labelyouwillrszerozero);
            this.panelyoupay4.Controls.Add(this.labelyouwillpay);
            this.panelyoupay4.Location = new System.Drawing.Point(266, 448);
            this.panelyoupay4.Name = "panelyoupay4";
            this.panelyoupay4.Size = new System.Drawing.Size(219, 191);
            this.panelyoupay4.TabIndex = 3;
            // 
            // labelamount
            // 
            this.labelamount.AutoSize = true;
            this.labelamount.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelamount.Location = new System.Drawing.Point(101, 141);
            this.labelamount.Name = "labelamount";
            this.labelamount.Size = new System.Drawing.Size(58, 18);
            this.labelamount.TabIndex = 5;
            this.labelamount.Text = "amount";
            // 
            // labelyoudonthaveany
            // 
            this.labelyoudonthaveany.AutoSize = true;
            this.labelyoudonthaveany.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyoudonthaveany.Location = new System.Drawing.Point(46, 114);
            this.labelyoudonthaveany.Name = "labelyoudonthaveany";
            this.labelyoudonthaveany.Size = new System.Drawing.Size(135, 18);
            this.labelyoudonthaveany.TabIndex = 3;
            this.labelyoudonthaveany.Text = "You Don\'t have any";
            // 
            // labelyoupointzerozero
            // 
            this.labelyoupointzerozero.AutoSize = true;
            this.labelyoupointzerozero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyoupointzerozero.Location = new System.Drawing.Point(64, 40);
            this.labelyoupointzerozero.Name = "labelyoupointzerozero";
            this.labelyoupointzerozero.Size = new System.Drawing.Size(28, 18);
            this.labelyoupointzerozero.TabIndex = 2;
            this.labelyoupointzerozero.Text = ".00";
            // 
            // labelyouwillrszerozero
            // 
            this.labelyouwillrszerozero.AutoSize = true;
            this.labelyouwillrszerozero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyouwillrszerozero.Location = new System.Drawing.Point(13, 39);
            this.labelyouwillrszerozero.Name = "labelyouwillrszerozero";
            this.labelyouwillrszerozero.Size = new System.Drawing.Size(56, 20);
            this.labelyouwillrszerozero.TabIndex = 1;
            this.labelyouwillrszerozero.Text = "Rs 00";
            // 
            // labelyouwillpay
            // 
            this.labelyouwillpay.AutoSize = true;
            this.labelyouwillpay.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyouwillpay.Location = new System.Drawing.Point(14, 9);
            this.labelyouwillpay.Name = "labelyouwillpay";
            this.labelyouwillpay.Size = new System.Drawing.Size(72, 18);
            this.labelyouwillpay.TabIndex = 0;
            this.labelyouwillpay.Text = "You\'ll Pay";
            // 
            // panelyoureceive3
            // 
            this.panelyoureceive3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.panelyoureceive3.BackColor = System.Drawing.Color.White;
            this.panelyoureceive3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelyoureceive3.Controls.Add(this.labelamounttobe);
            this.panelyoureceive3.Controls.Add(this.labelyoudonthave);
            this.panelyoureceive3.Controls.Add(this.labelyourecpointzero);
            this.panelyoureceive3.Controls.Add(this.labelyourecrszero);
            this.panelyoureceive3.Controls.Add(this.labelyoureceive);
            this.panelyoureceive3.Location = new System.Drawing.Point(24, 444);
            this.panelyoureceive3.Name = "panelyoureceive3";
            this.panelyoureceive3.Size = new System.Drawing.Size(222, 191);
            this.panelyoureceive3.TabIndex = 2;
            // 
            // labelamounttobe
            // 
            this.labelamounttobe.AutoSize = true;
            this.labelamounttobe.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelamounttobe.Location = new System.Drawing.Point(41, 141);
            this.labelamounttobe.Name = "labelamounttobe";
            this.labelamounttobe.Size = new System.Drawing.Size(154, 18);
            this.labelamounttobe.TabIndex = 5;
            this.labelamounttobe.Text = "amount to be received";
            // 
            // labelyoudonthave
            // 
            this.labelyoudonthave.AutoSize = true;
            this.labelyoudonthave.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyoudonthave.Location = new System.Drawing.Point(28, 114);
            this.labelyoudonthave.Name = "labelyoudonthave";
            this.labelyoudonthave.Size = new System.Drawing.Size(190, 18);
            this.labelyoudonthave.TabIndex = 3;
            this.labelyoudonthave.Text = "You Don\'t have any pending";
            // 
            // labelyourecpointzero
            // 
            this.labelyourecpointzero.AutoSize = true;
            this.labelyourecpointzero.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyourecpointzero.Location = new System.Drawing.Point(64, 40);
            this.labelyourecpointzero.Name = "labelyourecpointzero";
            this.labelyourecpointzero.Size = new System.Drawing.Size(28, 18);
            this.labelyourecpointzero.TabIndex = 2;
            this.labelyourecpointzero.Text = ".00";
            // 
            // labelyourecrszero
            // 
            this.labelyourecrszero.AutoSize = true;
            this.labelyourecrszero.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyourecrszero.Location = new System.Drawing.Point(13, 39);
            this.labelyourecrszero.Name = "labelyourecrszero";
            this.labelyourecrszero.Size = new System.Drawing.Size(56, 20);
            this.labelyourecrszero.TabIndex = 1;
            this.labelyourecrszero.Text = "Rs 00";
            // 
            // labelyoureceive
            // 
            this.labelyoureceive.AutoSize = true;
            this.labelyoureceive.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelyoureceive.Location = new System.Drawing.Point(14, 9);
            this.labelyoureceive.Name = "labelyoureceive";
            this.labelyoureceive.Size = new System.Drawing.Size(100, 18);
            this.labelyoureceive.TabIndex = 0;
            this.labelyoureceive.Text = "You\'ll Receive";
            // 
            // Homeusercontrol1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panelmainn);
            this.Controls.Add(this.panelmainprivacy);
            this.Name = "Homeusercontrol1";
            this.Size = new System.Drawing.Size(1049, 642);
            this.panelmainprivacy.ResumeLayout(false);
            this.panelmainprivacy.PerformLayout();
            this.paneldeliverychallan.ResumeLayout(false);
            this.paneldeliverychallan.PerformLayout();
            this.panelsaleorders.ResumeLayout(false);
            this.panelsaleorders.PerformLayout();
            this.panelloanacc.ResumeLayout(false);
            this.panelloanacc.PerformLayout();
            this.panelstockvalue.ResumeLayout(false);
            this.panelstockvalue.PerformLayout();
            this.panelcashinhand.ResumeLayout(false);
            this.panelcashinhand.PerformLayout();
            this.panellowstocks.ResumeLayout(false);
            this.panellowstocks.PerformLayout();
            this.panelstockinventory.ResumeLayout(false);
            this.panelstockinventory.PerformLayout();
            this.panelprivacy.ResumeLayout(false);
            this.panelprivacy.PerformLayout();
            this.panelmainn.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panelexpenses2.ResumeLayout(false);
            this.panelexpenses2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panelsale1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panelpurchase5.ResumeLayout(false);
            this.panelpurchase5.PerformLayout();
            this.panelyoupay4.ResumeLayout(false);
            this.panelyoupay4.PerformLayout();
            this.panelyoureceive3.ResumeLayout(false);
            this.panelyoureceive3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panelmainprivacy;
        private System.Windows.Forms.Panel panelstockinventory;
        private System.Windows.Forms.Label labelstockinventory;
        private System.Windows.Forms.Panel panelprivacy;
        private System.Windows.Forms.Label labelprivacy;
        private System.Windows.Forms.Panel panellowstocks;
        private System.Windows.Forms.Label labelsw2;
        private System.Windows.Forms.Label labelsw1;
        private System.Windows.Forms.Label labellowstock;
        private System.Windows.Forms.Label labelstkpointzero;
        private System.Windows.Forms.Label labelstockvalue;
        private System.Windows.Forms.Label labelstkrs;
        private System.Windows.Forms.Panel panelsaleorders;
        private System.Windows.Forms.Label labelopenzero;
        private System.Windows.Forms.Label labelnoofzero;
        private System.Windows.Forms.Label labelopensale;
        private System.Windows.Forms.Label labelnoofopenorders;
        private System.Windows.Forms.Label labelsaleorders;
        private System.Windows.Forms.Label labelsales;
        private System.Windows.Forms.Panel panelloanacc;
        private System.Windows.Forms.Label labelloanpointzero;
        private System.Windows.Forms.Label labelloanaacounts;
        private System.Windows.Forms.Label labelloanrs;
        private System.Windows.Forms.Panel panelstockvalue;
        private System.Windows.Forms.Label labelbankaccpointzero;
        private System.Windows.Forms.Label labelbankaccounts;
        private System.Windows.Forms.Label labelbankaccrs;
        private System.Windows.Forms.Panel panelcashinhand;
        private System.Windows.Forms.Label labelcashinpointzero;
        private System.Windows.Forms.Label labelchashinhand;
        private System.Windows.Forms.Label labelcashrs;
        private System.Windows.Forms.Label labelcashandbank;
        private System.Windows.Forms.Label labelfrontsw2;
        private System.Windows.Forms.Label labelfrontsw1;
        private System.Windows.Forms.Panel paneldeliverychallan;
        private System.Windows.Forms.Label labeldelivery0;
        private System.Windows.Forms.Label labeldeliverychallan;
        private System.Windows.Forms.Label labelnoofchallanzero;
        private System.Windows.Forms.Label labelnoofchallans;
        private System.Windows.Forms.Label labeldeliverychallans;
        private System.Windows.Forms.Panel panelmainn;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panelexpenses2;
        private System.Windows.Forms.Label labelrszeroo;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label labelthismont;
        private System.Windows.Forms.Label labelexpenses;
        private System.Windows.Forms.Panel panelsale1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelrs;
        private System.Windows.Forms.Label labelthismonth;
        private System.Windows.Forms.Label labeltotalsale;
        private System.Windows.Forms.Label labelzeropercent;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelsale;
        private System.Windows.Forms.Panel panelpurchase5;
        private System.Windows.Forms.Label labeltime;
        private System.Windows.Forms.Label labelpurchasethismonth;
        private System.Windows.Forms.Label labelitemsentered;
        private System.Windows.Forms.Label labelyouhave;
        private System.Windows.Forms.Label labelpurpointzero;
        private System.Windows.Forms.Label labelpurchaserszero;
        private System.Windows.Forms.Label labelpurchasee;
        private System.Windows.Forms.Panel panelyoupay4;
        private System.Windows.Forms.Label labelamount;
        private System.Windows.Forms.Label labelyoudonthaveany;
        private System.Windows.Forms.Label labelyoupointzerozero;
        private System.Windows.Forms.Label labelyouwillrszerozero;
        private System.Windows.Forms.Label labelyouwillpay;
        private System.Windows.Forms.Panel panelyoureceive3;
        private System.Windows.Forms.Label labelamounttobe;
        private System.Windows.Forms.Label labelyoudonthave;
        private System.Windows.Forms.Label labelyourecpointzero;
        private System.Windows.Forms.Label labelyourecrszero;
        private System.Windows.Forms.Label labelyoureceive;
    }
}
