﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using databaseconnwampp;
using MySql.Data.MySqlClient;

namespace SalesAndInventoryDummy
{
    public partial class Items : UserControl
    {
         
        private static Items _instance;

        public static Items Instance1
        {
            get
            {
                if (_instance == null)
                    _instance = new Items();
                return _instance;
            }
        }
        public Items()
        {
            InitializeComponent();
          
        }

        private void buttonproducts_Click(object sender, EventArgs e)
        {
             if (! panelfullfill.Controls.Contains(UserControlproducts.Instance))
            {
                panelfullfill.Controls.Add(UserControlproducts.Instance);
                UserControlproducts.Instance.Dock = DockStyle.Fill;
                UserControlproducts.Instance.BringToFront();
              
            }
            else
                UserControlproducts.Instance.BringToFront();
        }

        public static Control Instance { get; set; }

        private void button2_Click(object sender, EventArgs e)
        {
             if (! panelfullfill.Controls.Contains(UserControlservices.Instance2))
            {
                panelfullfill.Controls.Add(UserControlservices.Instance2);
                UserControlservices.Instance2.Dock = DockStyle.Fill;
                UserControlservices.Instance2.BringToFront();
              
            }
            else
                 UserControlservices.Instance2.BringToFront();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!panelfullfill.Controls.Contains(UserControlproducts.Instance1))
            {
                panelfullfill.Controls.Add(UserControlproducts.Instance1);
                UserControlproducts.Instance1.Dock = DockStyle.Fill;
                UserControlproducts.Instance1.BringToFront();
              
            }
            else
                 UserControlproducts.Instance1.BringToFront();
        }

        private void buttonmyonlinestore_Click(object sender, EventArgs e)
        {
            if (!panelfullfill.Controls.Contains(addnewunitusercontrol.Instance4))
            {
                panelfullfill.Controls.Add(addnewunitusercontrol.Instance4);
                addnewunitusercontrol.Instance4.Dock = DockStyle.Fill;
                addnewunitusercontrol.Instance4.BringToFront();

            }
            else
                addnewunitusercontrol.Instance4.BringToFront();
              
        }

        private void buttonunits_Click(object sender, EventArgs e)
        {
            if (!panelfullfill.Controls.Contains(unitUsercontrol .Instance3))
            {
                panelfullfill.Controls.Add(unitUsercontrol.Instance3);
                unitUsercontrol.Instance3.Dock = DockStyle.Fill;
                unitUsercontrol.Instance3.BringToFront();

            }
            else
                unitUsercontrol.Instance3.BringToFront();
        }

       
        }

        }
    
    

