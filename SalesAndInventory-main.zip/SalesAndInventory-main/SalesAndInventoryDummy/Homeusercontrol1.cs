﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesAndInventoryDummy
{
    public partial class Homeusercontrol1 : UserControl
    {
        private static Homeusercontrol1 _instance;

        public static Homeusercontrol1 Instance
    {
            get
            {   
            if(_instance==null )
                _instance=new Homeusercontrol1();
            return _instance;
            }
    }
    
   
        public Homeusercontrol1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
