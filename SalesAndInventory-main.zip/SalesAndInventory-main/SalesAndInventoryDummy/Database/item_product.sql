-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 02, 2021 at 06:28 PM
-- Server version: 8.0.18
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `salesandinventorydummy`
--

-- --------------------------------------------------------

--
-- Table structure for table `item_product`
--

DROP TABLE IF EXISTS `item_product`;
CREATE TABLE IF NOT EXISTS `item_product` (
  `Item_id` int(11) NOT NULL AUTO_INCREMENT,
  `Item_name` varchar(50) NOT NULL,
  `Item_HSN` varchar(30) NOT NULL,
  `Base_unit` varchar(20) NOT NULL,
  `Secondary_unit` varchar(20) NOT NULL,
  `Item_code` varchar(30) NOT NULL,
  `Sale_price` varchar(10) NOT NULL,
  `Tax_In_Ex` varchar(20) NOT NULL,
  `Purchase_price` varchar(10) NOT NULL,
  `Tax_Inc_Exc` varchar(20) NOT NULL,
  `Tax_rate` varchar(20) NOT NULL,
  `Discount_type` varchar(20) NOT NULL,
  `Discount_on_saleprice` varchar(20) NOT NULL,
  PRIMARY KEY (`Item_id`,`Item_HSN`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
