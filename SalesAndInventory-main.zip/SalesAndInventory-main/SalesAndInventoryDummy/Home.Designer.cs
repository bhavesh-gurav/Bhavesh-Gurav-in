﻿namespace SalesAndInventoryDummy
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelstarting = new System.Windows.Forms.Label();
            this.buttonaddsaleinvoice = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // labelstarting
            // 
            this.labelstarting.AutoSize = true;
            this.labelstarting.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelstarting.Location = new System.Drawing.Point(313, 146);
            this.labelstarting.Name = "labelstarting";
            this.labelstarting.Size = new System.Drawing.Size(335, 23);
            this.labelstarting.TabIndex = 0;
            this.labelstarting.Text = "Start using Sales and Inventory by ";
            // 
            // buttonaddsaleinvoice
            // 
            this.buttonaddsaleinvoice.Font = new System.Drawing.Font("Modern No. 20", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonaddsaleinvoice.Location = new System.Drawing.Point(432, 247);
            this.buttonaddsaleinvoice.Name = "buttonaddsaleinvoice";
            this.buttonaddsaleinvoice.Size = new System.Drawing.Size(197, 44);
            this.buttonaddsaleinvoice.TabIndex = 1;
            this.buttonaddsaleinvoice.Text = "ADD SALE INVOICE";
            this.buttonaddsaleinvoice.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Rockwell", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(448, 188);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(302, 23);
            this.label1.TabIndex = 2;
            this.label1.Text = "creating your first Sale Invoice";
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(796, 443);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonaddsaleinvoice);
            this.Controls.Add(this.labelstarting);
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Home";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelstarting;
        private System.Windows.Forms.Button buttonaddsaleinvoice;
        private System.Windows.Forms.Label label1;
    }
}