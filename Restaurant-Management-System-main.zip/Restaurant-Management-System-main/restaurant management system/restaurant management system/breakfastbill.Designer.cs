﻿namespace restaurant_management_system
{
    partial class breakfastbill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.TableNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Order = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Price = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tablenoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.boileggsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.breadbutterDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sandwichDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cornflexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pohaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.saladDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.omletDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.teaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.coffeeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.greenteaDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.milkDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.mixfruitjuiceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orangjuiceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.breakfastBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseDataSet1 = new restaurant_management_system.DatabaseDataSet1();
            this.breakfastTableAdapter = new restaurant_management_system.DatabaseDataSet1TableAdapters.breakfastTableAdapter();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.breakfastBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.Yellow;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TableNo,
            this.Order,
            this.Quantity,
            this.Price,
            this.Amount});
            this.dataGridView1.Location = new System.Drawing.Point(596, 150);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(457, 217);
            this.dataGridView1.TabIndex = 0;
            // 
            // TableNo
            // 
            this.TableNo.HeaderText = "TableNo";
            this.TableNo.Name = "TableNo";
            this.TableNo.Width = 80;
            // 
            // Order
            // 
            this.Order.HeaderText = "order";
            this.Order.Name = "Order";
            this.Order.Width = 80;
            // 
            // Quantity
            // 
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            this.Quantity.Width = 80;
            // 
            // Price
            // 
            this.Price.HeaderText = "Price";
            this.Price.Name = "Price";
            this.Price.Width = 80;
            // 
            // Amount
            // 
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.Width = 90;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(25, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 19);
            this.label1.TabIndex = 1;
            this.label1.Text = "Table No";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(592, 123);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 19);
            this.label2.TabIndex = 2;
            this.label2.Text = "Order Food";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(126, 50);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(124, 27);
            this.textBox1.TabIndex = 3;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Boil Eggs",
            "Bread Butter",
            "Sandwich",
            "Cornflex",
            "Poha ",
            "Salad",
            "Omlet",
            "Tea",
            "Coffee",
            "Green Tea",
            "Milk",
            "Mix Fruit Juice",
            "Orange Juice"});
            this.comboBox1.Location = new System.Drawing.Point(700, 115);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(149, 27);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(895, 123);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "Price";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(965, 115);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(88, 27);
            this.textBox2.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(666, 379);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(78, 27);
            this.textBox3.TabIndex = 8;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(593, 387);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "Quantity";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(888, 379);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(109, 27);
            this.textBox4.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(787, 387);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(99, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "Total Amount";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Aqua;
            this.button1.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(965, 438);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(81, 33);
            this.button1.TabIndex = 11;
            this.button1.Text = "Total";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Aqua;
            this.button2.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(831, 438);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(81, 33);
            this.button2.TabIndex = 12;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Aqua;
            this.button3.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(700, 438);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(81, 33);
            this.button3.TabIndex = 13;
            this.button3.Text = "New";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Aqua;
            this.button4.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(1003, 380);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(67, 26);
            this.button4.TabIndex = 14;
            this.button4.Text = "price";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.Aqua;
            this.button5.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(31, 150);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(81, 33);
            this.button5.TabIndex = 16;
            this.button5.Text = "Search";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Aqua;
            this.button6.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.Location = new System.Drawing.Point(318, 150);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(81, 33);
            this.button6.TabIndex = 17;
            this.button6.Text = "Remove";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.Yellow;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tablenoDataGridViewTextBoxColumn,
            this.boileggsDataGridViewTextBoxColumn,
            this.breadbutterDataGridViewTextBoxColumn,
            this.sandwichDataGridViewTextBoxColumn,
            this.cornflexDataGridViewTextBoxColumn,
            this.pohaDataGridViewTextBoxColumn,
            this.saladDataGridViewTextBoxColumn,
            this.omletDataGridViewTextBoxColumn,
            this.teaDataGridViewTextBoxColumn,
            this.coffeeDataGridViewTextBoxColumn,
            this.greenteaDataGridViewTextBoxColumn,
            this.milkDataGridViewTextBoxColumn,
            this.mixfruitjuiceDataGridViewTextBoxColumn,
            this.orangjuiceDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.breakfastBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(4, 197);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(586, 170);
            this.dataGridView2.TabIndex = 18;
            // 
            // tablenoDataGridViewTextBoxColumn
            // 
            this.tablenoDataGridViewTextBoxColumn.DataPropertyName = "Tableno";
            this.tablenoDataGridViewTextBoxColumn.HeaderText = "Tableno";
            this.tablenoDataGridViewTextBoxColumn.Name = "tablenoDataGridViewTextBoxColumn";
            // 
            // boileggsDataGridViewTextBoxColumn
            // 
            this.boileggsDataGridViewTextBoxColumn.DataPropertyName = "boileggs";
            this.boileggsDataGridViewTextBoxColumn.HeaderText = "boileggs";
            this.boileggsDataGridViewTextBoxColumn.Name = "boileggsDataGridViewTextBoxColumn";
            // 
            // breadbutterDataGridViewTextBoxColumn
            // 
            this.breadbutterDataGridViewTextBoxColumn.DataPropertyName = "breadbutter";
            this.breadbutterDataGridViewTextBoxColumn.HeaderText = "breadbutter";
            this.breadbutterDataGridViewTextBoxColumn.Name = "breadbutterDataGridViewTextBoxColumn";
            // 
            // sandwichDataGridViewTextBoxColumn
            // 
            this.sandwichDataGridViewTextBoxColumn.DataPropertyName = "sandwich";
            this.sandwichDataGridViewTextBoxColumn.HeaderText = "sandwich";
            this.sandwichDataGridViewTextBoxColumn.Name = "sandwichDataGridViewTextBoxColumn";
            // 
            // cornflexDataGridViewTextBoxColumn
            // 
            this.cornflexDataGridViewTextBoxColumn.DataPropertyName = "cornflex";
            this.cornflexDataGridViewTextBoxColumn.HeaderText = "cornflex";
            this.cornflexDataGridViewTextBoxColumn.Name = "cornflexDataGridViewTextBoxColumn";
            // 
            // pohaDataGridViewTextBoxColumn
            // 
            this.pohaDataGridViewTextBoxColumn.DataPropertyName = "poha";
            this.pohaDataGridViewTextBoxColumn.HeaderText = "poha";
            this.pohaDataGridViewTextBoxColumn.Name = "pohaDataGridViewTextBoxColumn";
            // 
            // saladDataGridViewTextBoxColumn
            // 
            this.saladDataGridViewTextBoxColumn.DataPropertyName = "salad";
            this.saladDataGridViewTextBoxColumn.HeaderText = "salad";
            this.saladDataGridViewTextBoxColumn.Name = "saladDataGridViewTextBoxColumn";
            // 
            // omletDataGridViewTextBoxColumn
            // 
            this.omletDataGridViewTextBoxColumn.DataPropertyName = "omlet";
            this.omletDataGridViewTextBoxColumn.HeaderText = "omlet";
            this.omletDataGridViewTextBoxColumn.Name = "omletDataGridViewTextBoxColumn";
            // 
            // teaDataGridViewTextBoxColumn
            // 
            this.teaDataGridViewTextBoxColumn.DataPropertyName = "tea";
            this.teaDataGridViewTextBoxColumn.HeaderText = "tea";
            this.teaDataGridViewTextBoxColumn.Name = "teaDataGridViewTextBoxColumn";
            // 
            // coffeeDataGridViewTextBoxColumn
            // 
            this.coffeeDataGridViewTextBoxColumn.DataPropertyName = "coffee";
            this.coffeeDataGridViewTextBoxColumn.HeaderText = "coffee";
            this.coffeeDataGridViewTextBoxColumn.Name = "coffeeDataGridViewTextBoxColumn";
            // 
            // greenteaDataGridViewTextBoxColumn
            // 
            this.greenteaDataGridViewTextBoxColumn.DataPropertyName = "greentea";
            this.greenteaDataGridViewTextBoxColumn.HeaderText = "greentea";
            this.greenteaDataGridViewTextBoxColumn.Name = "greenteaDataGridViewTextBoxColumn";
            // 
            // milkDataGridViewTextBoxColumn
            // 
            this.milkDataGridViewTextBoxColumn.DataPropertyName = "milk";
            this.milkDataGridViewTextBoxColumn.HeaderText = "milk";
            this.milkDataGridViewTextBoxColumn.Name = "milkDataGridViewTextBoxColumn";
            // 
            // mixfruitjuiceDataGridViewTextBoxColumn
            // 
            this.mixfruitjuiceDataGridViewTextBoxColumn.DataPropertyName = "mixfruit_juice";
            this.mixfruitjuiceDataGridViewTextBoxColumn.HeaderText = "mixfruit_juice";
            this.mixfruitjuiceDataGridViewTextBoxColumn.Name = "mixfruitjuiceDataGridViewTextBoxColumn";
            // 
            // orangjuiceDataGridViewTextBoxColumn
            // 
            this.orangjuiceDataGridViewTextBoxColumn.DataPropertyName = "orang_juice";
            this.orangjuiceDataGridViewTextBoxColumn.HeaderText = "orang_juice";
            this.orangjuiceDataGridViewTextBoxColumn.Name = "orangjuiceDataGridViewTextBoxColumn";
            // 
            // breakfastBindingSource
            // 
            this.breakfastBindingSource.DataMember = "breakfast";
            this.breakfastBindingSource.DataSource = this.databaseDataSet1;
            // 
            // databaseDataSet1
            // 
            this.databaseDataSet1.DataSetName = "DatabaseDataSet1";
            this.databaseDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // breakfastTableAdapter
            // 
            this.breakfastTableAdapter.ClearBeforeFill = true;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Aqua;
            this.button7.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.Location = new System.Drawing.Point(169, 150);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(81, 33);
            this.button7.TabIndex = 19;
            this.button7.Text = "view all";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Aqua;
            this.button8.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button8.Location = new System.Drawing.Point(138, 402);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(144, 33);
            this.button8.TabIndex = 20;
            this.button8.Text = "Preview";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.Color.Aqua;
            this.button9.Font = new System.Drawing.Font("Calibri", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button9.Location = new System.Drawing.Point(328, 402);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(144, 33);
            this.button9.TabIndex = 21;
            this.button9.Text = "Close";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // breakfastbill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Red;
            this.BackgroundImage = global::restaurant_management_system.Properties.Resources.darshan3;
            this.ClientSize = new System.Drawing.Size(1071, 515);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "breakfastbill";
            this.Text = "breakfastbill";
            this.Load += new System.EventHandler(this.breakfastbill_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.breakfastBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseDataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.DataGridViewTextBoxColumn TableNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Order;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Price;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.DataGridView dataGridView2;
        private DatabaseDataSet1 databaseDataSet1;
        private System.Windows.Forms.BindingSource breakfastBindingSource;
        private DatabaseDataSet1TableAdapters.breakfastTableAdapter breakfastTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn tablenoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn boileggsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn breadbutterDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sandwichDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cornflexDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pohaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn saladDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn omletDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn teaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn coffeeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn greenteaDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn milkDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn mixfruitjuiceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orangjuiceDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;



    }
}